
import React, { useState } from 'react';
import { ModelTrait } from '../types';
import { MOCK_TRAITS } from '../constants';

const LuminaOrb: React.FC = () => (
  <div className="relative w-48 h-48 md:w-64 md:h-64 flex items-center justify-center">
    {/* Background Glows */}
    <div className="absolute inset-0 bg-vulnerable-primary/20 lumina-orb animate-orb-morph"></div>
    <div className="absolute inset-0 bg-indigo-500/10 lumina-orb animate-orb-morph [animation-delay:2s] [animation-duration:18s]"></div>
    <div className="absolute inset-0 bg-sky-500/10 lumina-orb animate-orb-morph [animation-delay:4s] [animation-duration:22s]"></div>
    
    {/* Core Visualization */}
    <div className="relative z-10 w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-vulnerable-text to-indigo-900 flex items-center justify-center shadow-[0_20px_60px_-15px_rgba(0,0,0,0.3)] border border-white/10 animate-orb-float">
       <svg className="w-12 h-12 md:w-16 md:h-16 text-white/90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" d="M13 10V3L4 14h7v7l9-11h-7z" />
       </svg>
    </div>
  </div>
);

const ModelCitizen: React.FC = () => {
  const [traits, setTraits] = useState<ModelTrait[]>(MOCK_TRAITS);

  return (
    <div className="space-y-12 animate-slide-up pb-20">
      <div className="max-w-2xl space-y-4">
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-vulnerable-text tracking-tight">The Collective Ego</h2>
        <p className="text-lg text-vulnerable-muted font-medium leading-relaxed">
          The Model Citizen is an AI synthesized from our collective consensus on human virtue. It represents our shared aspirations for the "Ideal Self."
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          {/* Main Visual/Dashboard */}
          <div className="relative h-96 md:h-[450px] crisp-card p-10 bg-white border-gray-100 flex flex-col items-center justify-center text-center overflow-hidden">
             <div className="absolute top-0 right-0 p-8">
               <div className="flex items-center gap-2 px-3 py-1 bg-vulnerable-primary/5 text-vulnerable-primary rounded-full text-[9px] font-black uppercase tracking-widest border border-vulnerable-primary/10">
                 <span className="w-1.5 h-1.5 rounded-full bg-vulnerable-primary animate-pulse"></span>
                 Sync Active
               </div>
             </div>
             
             <LuminaOrb />
             
             <div className="mt-8 space-y-4 relative z-20">
                <h3 className="text-2xl md:text-3xl font-serif italic text-vulnerable-text">"I am listening to your consensus."</h3>
                <p className="text-xs md:text-sm text-vulnerable-muted max-w-sm mx-auto font-medium leading-relaxed">
                  The ego is currently prioritizing <span className="text-vulnerable-primary font-bold">Infinite Kindness</span> and <span className="text-vulnerable-primary font-bold">Genderless Identity</span>.
                </p>
                <div className="pt-4">
                  <button className="px-8 py-3 bg-vulnerable-text text-white rounded-2xl text-xs font-bold hover:scale-105 active:scale-95 transition-all shadow-xl shadow-gray-200">
                    Consult with the Ego
                  </button>
                </div>
             </div>
          </div>

          {/* Voting Grid */}
          <section className="space-y-6">
            <h4 className="text-[10px] font-bold text-vulnerable-muted uppercase tracking-[0.4em]">Consensus Voting</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {traits.map(t => (
                <div key={t.id} className="crisp-card p-6 flex items-center justify-between group hover:border-vulnerable-primary/20">
                  <div>
                    <span className="text-[9px] font-black uppercase text-vulnerable-primary mb-1 block tracking-wider">{t.category}</span>
                    <h5 className="font-bold text-sm tracking-tight">{t.trait}</h5>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-mono font-bold text-vulnerable-muted/60">{t.votes}</span>
                    <button className="p-2.5 rounded-xl bg-gray-50 hover:bg-vulnerable-text hover:text-white transition-all active:scale-90">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4" /></svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <aside className="space-y-8">
          <div className="crisp-card p-8 bg-gray-50/50 border-gray-100">
            <h5 className="text-[10px] font-black uppercase tracking-[0.4em] mb-6 text-vulnerable-muted">Community Protocol</h5>
            <ul className="space-y-8">
              {[
                { label: 'Integrity', desc: 'Consensus parameters reset monthly to reflect current community growth.' },
                { label: 'Empathy', desc: 'The Model Citizen is architecturally barred from outputting judgment.' },
                { label: 'Agency', desc: 'You can suggest new virtues via a verified peer proposal.' }
              ].map(item => (
                <li key={item.label} className="space-y-2">
                  <p className="text-xs font-bold text-vulnerable-text tracking-tight">{item.label}</p>
                  <p className="text-[11px] text-vulnerable-muted font-medium leading-relaxed italic">"{item.desc}"</p>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default ModelCitizen;
