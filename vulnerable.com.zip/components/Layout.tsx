
import React, { useState } from 'react';
import { VulnerableUser, FeedChannel } from '../types';
import SEO from './SEO';

interface LayoutProps {
  user: VulnerableUser;
  activeView: string;
  activeChannel?: FeedChannel;
  setActiveView: (view: string) => void;
  setActiveChannel: (channel: FeedChannel) => void;
  onOpenCalibration: () => void;
  onLogout: () => void;
  zenMode?: boolean;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ 
  user, 
  activeView, 
  activeChannel, 
  setActiveView, 
  setActiveChannel, 
  onOpenCalibration,
  onLogout,
  zenMode = false,
  children 
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const channels: { id: FeedChannel; label: string; desc: string; icon: string }[] = [
    { id: 'garden', label: 'The Garden', desc: 'Verified Growth', icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
    { id: 'void', label: 'The Void', desc: 'Raw Catharsis', icon: 'M21 12a9 9 0 11-18 0 9 9 0 0118 0z M12 9v2m0 4h.01' },
    { id: 'mirror', label: 'The Mirror', desc: 'Self Observation', icon: 'M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z' },
  ];

  // Dynamic SEO metadata based on view
  const getSEOProps = () => {
    switch(activeView) {
      case 'feed': return { title: `Feed - ${activeChannel}`, description: `Explore radical honesty in the ${activeChannel} channel.` };
      case 'forge': return { title: 'The Forge', description: 'Analyze integrity dilemmas with AI precedents.' };
      case 'profile': return { title: user.displayName, description: user.bio };
      case 'vault': return { title: 'The Vault', description: 'Browse community archives of resilience.' };
      default: return { title: 'The Truth Network' };
    }
  };

  const NavContent = () => (
    <nav className="flex flex-col h-full py-8 px-6" aria-label="Main Navigation">
      <div className="flex items-center gap-3 mb-12">
        <div className="w-10 h-10 bg-black rounded-2xl flex items-center justify-center text-white font-serif font-bold text-2xl">V</div>
        <h1 className="text-sm font-bold uppercase tracking-[0.4em] text-black">Vulnerable</h1>
      </div>

      <div className="flex-1 space-y-10 overflow-y-auto no-scrollbar">
        <section>
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400 mb-6 pl-2">Channels</h2>
          <div className="space-y-1">
            {channels.map((channel) => (
              <button
                key={channel.id}
                onClick={() => {
                  setActiveView('feed');
                  setActiveChannel(channel.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full group flex items-center gap-4 px-4 py-4 rounded-2xl transition-all duration-300 ${
                  activeView === 'feed' && activeChannel === channel.id 
                    ? 'bg-black text-white shadow-xl translate-x-1' 
                    : 'text-zinc-500 hover:bg-zinc-100 hover:text-black'
                }`}
                aria-current={activeView === 'feed' && activeChannel === channel.id ? 'page' : undefined}
              >
                <div className={`w-5 h-5 shrink-0 transition-colors ${activeView === 'feed' && activeChannel === channel.id ? 'text-white' : 'text-zinc-300 group-hover:text-black'}`}>
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={channel.icon} /></svg>
                </div>
                <p className="text-xs font-bold leading-tight tracking-tight">{channel.label}</p>
              </button>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400 mb-6 pl-2">Intelligence</h2>
          <div className="space-y-1">
            <button
              onClick={() => { setActiveView('forge'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
                activeView === 'forge' ? 'bg-black text-white shadow-xl translate-x-1' : 'text-zinc-500 hover:bg-zinc-100'
              }`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
              <span className="text-xs font-bold">The Forge</span>
            </button>
            <button
              onClick={() => { setActiveView('radar'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
                activeView === 'radar' ? 'bg-black text-white shadow-xl translate-x-1' : 'text-zinc-500 hover:bg-zinc-100'
              }`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              <span className="text-xs font-bold">Resonance Radar</span>
            </button>
          </div>
        </section>

        <section>
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400 mb-6 pl-2">The Archive</h2>
          <div className="space-y-1">
            <button
              onClick={() => { setActiveView('vault'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
                activeView === 'vault' ? 'bg-black text-white shadow-xl translate-x-1' : 'text-zinc-500 hover:bg-zinc-100'
              }`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4" /></svg>
              <span className="text-xs font-bold">The Vault</span>
            </button>
            <button
              onClick={() => { setActiveView('material'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
                activeView === 'material' ? 'bg-black text-white shadow-xl translate-x-1' : 'text-zinc-500 hover:bg-zinc-100'
              }`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              <span className="text-xs font-bold">Material Archive</span>
            </button>
          </div>
        </section>
      </div>

      <div className="mt-auto space-y-3 pt-6 border-t border-zinc-50">
        <div className="px-4 py-3 bg-zinc-50 rounded-2xl border border-zinc-100 mb-2">
           <div className="flex items-center justify-between mb-2">
             <span className="text-[8px] font-black uppercase tracking-widest text-zinc-400">Truth Equity</span>
             <span className="text-[8px] font-mono font-bold text-black">{user.truthEquity.score}</span>
           </div>
           <div className="w-full h-1 bg-zinc-200 rounded-full overflow-hidden">
             <div className="h-full bg-black transition-all" style={{ width: `${Math.min(100, (user.truthEquity.score/1000)*100)}%` }} role="progressbar" aria-valuenow={user.truthEquity.score} aria-valuemin={0} aria-valuemax={1000}></div>
           </div>
        </div>
        <button 
          onClick={() => { setActiveView('profile'); setIsMobileMenuOpen(false); }}
          className={`w-full p-4 rounded-3xl border transition-all ${
            activeView === 'profile' ? 'bg-black text-white border-black shadow-xl' : 'bg-white border-zinc-100 text-zinc-500 hover:border-black hover:text-black shadow-sm'
          }`}
          aria-label="View My Profile"
        >
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shadow-inner transition-colors ${activeView === 'profile' ? 'bg-zinc-800 text-white' : 'bg-black text-white'}`}>
              {user.displayName?.charAt(0)}
            </div>
            <div className="min-w-0 text-left">
              <p className="text-xs font-bold truncate">{user.displayName}</p>
              <p className="text-[9px] font-black uppercase tracking-widest text-emerald-500">View Profile</p>
            </div>
          </div>
        </button>
      </div>
    </nav>
  );

  return (
    <div className="flex h-screen bg-vulnerable-bg text-vulnerable-text font-sans overflow-hidden">
      <SEO {...getSEOProps()} />
      <aside className={`transition-all duration-700 ease-in-out ${zenMode ? 'w-0 opacity-0' : 'w-72 opacity-100'} hidden lg:flex bg-white border-r border-vulnerable-border flex-col shrink-0 overflow-hidden`}>
        {NavContent()}
      </aside>
      <div className="flex-1 flex flex-col relative overflow-hidden">
        <header className={`h-20 glass flex items-center justify-between px-6 lg:px-12 z-40 shrink-0 border-b border-vulnerable-border transition-transform duration-700 ${zenMode ? '-translate-y-full' : 'translate-y-0'}`}>
          <div className="flex items-center gap-4">
            <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2.5 bg-zinc-100 rounded-xl" aria-label="Open navigation menu">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 6h16M4 12h16m-16 6h16" /></svg>
            </button>
            <button 
              onClick={onOpenCalibration}
              className="flex items-center gap-3 px-5 py-2.5 bg-zinc-50 hover:bg-zinc-100 rounded-2xl border border-zinc-100 transition-all group"
              aria-label="Synchronize internal frequency"
            >
               <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
               <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600 group-hover:text-black">Sync Frequency</span>
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setActiveView('gatekeeper')}
              className="text-[10px] font-black uppercase tracking-[0.15em] px-5 py-2.5 bg-black text-white rounded-xl transition-all shadow-lg shadow-zinc-200"
            >
              Verify Peer
            </button>
          </div>
        </header>
        <main id="main-content" className="flex-1 overflow-y-auto overflow-x-hidden relative v-scroll-area no-scrollbar">
          <div className={`transition-all duration-1000 w-full px-6 md:px-12 pb-40 lg:pb-64 ${zenMode ? 'max-w-4xl mx-auto pt-10' : 'max-w-7xl mx-auto py-12 lg:py-16'}`}>
            {children}
          </div>
        </main>
      </div>
      <div className={`fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm lg:hidden transition-opacity duration-500 ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMobileMenuOpen(false)}>
        <div className={`absolute left-0 top-0 bottom-0 w-[85%] max-w-sm bg-white shadow-2xl transition-transform duration-500 ease-out ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`} onClick={(e) => e.stopPropagation()}>
          {NavContent()}
        </div>
      </div>
    </div>
  );
};

export default Layout;
