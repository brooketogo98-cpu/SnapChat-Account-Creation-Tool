
import React, { useState } from 'react';
import { MaterialItem } from '../types';

interface Props {
  items: MaterialItem[];
  onRegister: (item: MaterialItem) => void;
}

const MaterialArchive: React.FC<Props> = ({ items, onRegister }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', history: '' });

  const handleRegister = () => {
    if (!form.title || !form.history) return;
    const newItem: MaterialItem = {
      id: `mat-${Date.now()}`,
      ...form,
      dateAdded: new Date()
    };
    onRegister(newItem);
    setForm({ title: '', description: '', history: '' });
    setIsAdding(false);
  };

  return (
    <div className="space-y-12 animate-slide-up pb-20 max-w-6xl mx-auto">
      <div className="max-w-2xl space-y-4">
        <h2 className="text-3xl md:text-5xl font-serif font-bold text-vulnerable-text tracking-tight">The Material Archive</h2>
        <p className="text-lg text-vulnerable-muted leading-relaxed font-medium">
          A catalogue of physical objects that define us. Not for their cost, but for their stories. Every scuff and scratch is part of the narrative.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {items.map(item => (
          <div key={item.id} className="bg-white border border-zinc-100 rounded-[2.5rem] group overflow-hidden flex flex-col h-full shadow-sm hover:border-black transition-all">
            <div className="h-48 bg-zinc-50 flex items-center justify-center relative border-b border-zinc-100">
               <svg className="w-12 h-12 text-zinc-300 opacity-20 group-hover:scale-110 transition-transform duration-700 ease-out" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
               </svg>
            </div>
            <div className="p-8 space-y-5 flex-1 flex flex-col">
              <div className="space-y-1">
                <span className="text-[10px] font-black text-black uppercase tracking-widest bg-zinc-50 px-3 py-1 rounded-full">Archive Record</span>
                <h3 className="text-2xl font-bold text-black">{item.title}</h3>
              </div>
              <div className="space-y-3 flex-1">
                <p className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider">Provenance</p>
                <p className="text-black italic font-serif text-lg leading-relaxed">"{item.history}"</p>
              </div>
            </div>
          </div>
        ))}

        <button 
          onClick={() => setIsAdding(true)}
          className="bg-white border-dashed border-2 border-zinc-200 rounded-[2.5rem] min-h-[400px] flex flex-col items-center justify-center space-y-6 text-zinc-400 hover:text-black hover:border-black transition-all group active:scale-[0.98]"
        >
          <div className="w-16 h-16 rounded-full bg-zinc-50 border border-zinc-100 flex items-center justify-center group-hover:scale-110 transition-transform">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" /></svg>
          </div>
          <div className="text-center px-6">
            <p className="font-bold text-sm text-black">Register Possession</p>
            <p className="text-[11px] font-medium mt-1">Upload photos and document history</p>
          </div>
        </button>
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-[200] bg-black/40 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] w-full max-w-lg p-12 space-y-10 shadow-2xl animate-slide-up">
            <h3 className="text-3xl font-serif italic">Archive Enrollment</h3>
            <div className="space-y-6">
              <input 
                type="text" 
                placeholder="Object Name (e.g. My First Sketchbook)"
                value={form.title}
                onChange={e => setForm({...form, title: e.target.value})}
                className="w-full bg-zinc-50 border-none rounded-2xl p-4 text-sm"
              />
              <textarea 
                placeholder="The narrative history of this object..."
                value={form.history}
                onChange={e => setForm({...form, history: e.target.value})}
                className="w-full bg-zinc-50 border-none rounded-2xl p-4 text-sm h-32"
              />
            </div>
            <div className="flex gap-4">
              <button onClick={() => setIsAdding(false)} className="flex-1 py-4 text-xs font-black uppercase text-zinc-400">Cancel</button>
              <button onClick={handleRegister} className="flex-1 py-4 bg-black text-white rounded-2xl text-xs font-black uppercase shadow-lg">Commit to Archive</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MaterialArchive;
