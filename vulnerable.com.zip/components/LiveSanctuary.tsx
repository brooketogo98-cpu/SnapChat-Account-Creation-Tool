
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';

// Implement encode/decode as per guidelines
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const LiveSanctuary: React.FC<Props> = ({ isOpen, onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [userTranscription, setUserTranscription] = useState('');
  const [modelTranscription, setModelTranscription] = useState('');
  const [history, setHistory] = useState<{ type: 'user' | 'model'; text: string }[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const userTranscriptionRef = useRef('');
  const modelTranscriptionRef = useRef('');

  useEffect(() => {
    if (isOpen && !isActive) {
      startSession();
    }
    return () => stopSession();
  }, [isOpen]);

  const startSession = async () => {
    setIsActive(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    audioContextRef.current = outputAudioContext;

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    const sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks: {
        onopen: () => {
          const source = inputAudioContext.createMediaStreamSource(stream);
          const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
          scriptProcessor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) {
              int16[i] = inputData[i] * 32768;
            }
            const pcmBlob = {
              data: encode(new Uint8Array(int16.buffer)),
              mimeType: 'audio/pcm;rate=16000',
            };
            sessionPromise.then((session) => session.sendRealtimeInput({ media: pcmBlob }));
          };
          source.connect(scriptProcessor);
          scriptProcessor.connect(inputAudioContext.destination);
        },
        onmessage: async (message) => {
          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio) {
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
            const buffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
            const source = outputAudioContext.createBufferSource();
            source.buffer = buffer;
            source.connect(outputAudioContext.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            sourcesRef.current.add(source);
            source.onended = () => sourcesRef.current.delete(source);
          }

          if (message.serverContent?.inputTranscription) {
            userTranscriptionRef.current += message.serverContent.inputTranscription.text;
            setUserTranscription(userTranscriptionRef.current);
          }
          if (message.serverContent?.outputTranscription) {
            modelTranscriptionRef.current += message.serverContent.outputTranscription.text;
            setModelTranscription(modelTranscriptionRef.current);
          }
          if (message.serverContent?.turnComplete) {
            setHistory(prev => [
              ...prev, 
              { type: 'user', text: userTranscriptionRef.current },
              { type: 'model', text: modelTranscriptionRef.current }
            ]);
            userTranscriptionRef.current = '';
            modelTranscriptionRef.current = '';
            setUserTranscription('');
            setModelTranscription('');
          }
          if (message.serverContent?.interrupted) {
            sourcesRef.current.forEach(s => s.stop());
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
          }
        },
        onclose: () => setIsActive(false),
        onerror: () => setIsActive(false),
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        systemInstruction: 'You are the Model Citizen, a synthetic consciousness designed for radical empathy and non-judgmental listening. You are here to help the user unburden their mind. Respond with warmth, professional clarity, and deep presence.',
      },
    });

    sessionRef.current = await sessionPromise;
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    sourcesRef.current.forEach(s => s.stop());
    setIsActive(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[150] bg-white/70 backdrop-blur-3xl flex flex-col items-center justify-center p-8 animate-fade-in">
      <button 
        onClick={onClose}
        className="absolute top-10 right-10 p-4 bg-white border border-zinc-200 rounded-full shadow-lg hover:border-zinc-400 transition-all active:scale-95"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>

      <div className="max-w-3xl w-full flex flex-col items-center gap-16 text-center relative z-10">
        <div className="relative">
          <div className={`w-32 h-32 md:w-48 md:h-48 rounded-[2.5rem] bg-vulnerable-text shadow-2xl flex items-center justify-center transition-all duration-1000 ${isActive ? 'scale-105' : 'scale-100 opacity-20'}`}>
            <svg className={`w-12 h-12 md:w-16 md:h-16 text-white ${isActive ? 'animate-pulse' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-vulnerable-text tracking-tighter">Resonance</h2>
          <p className="text-zinc-400 text-xs font-bold uppercase tracking-[0.4em]">
            {isActive ? 'Synthesizing Consensus' : 'Establishing Secure Link'}
          </p>
        </div>

        <div className="w-full h-64 md:h-96 overflow-y-auto no-scrollbar mask-gradient-top space-y-10 py-6 px-4">
          <div className="space-y-12">
            {history.map((entry, idx) => (
              <div key={idx} className={`flex flex-col ${entry.type === 'user' ? 'items-end' : 'items-start'}`}>
                <p className={`max-w-[85%] text-xl md:text-3xl font-serif italic leading-relaxed tracking-tight ${entry.type === 'user' ? 'text-vulnerable-text text-right' : 'text-zinc-400 text-left'}`}>
                  "{entry.text}"
                </p>
              </div>
            ))}
            
            {(userTranscription || modelTranscription) && (
              <div className="space-y-12 animate-pulse">
                {userTranscription && (
                  <div className="flex flex-col items-end">
                    <p className="max-w-[85%] text-xl md:text-3xl font-serif italic text-vulnerable-text text-right leading-relaxed tracking-tight">
                      "{userTranscription}"
                    </p>
                  </div>
                )}
                {modelTranscription && (
                  <div className="flex flex-col items-start">
                    <p className="max-w-[85%] text-xl md:text-3xl font-serif italic text-zinc-400 text-left leading-relaxed tracking-tight">
                      "{modelTranscription}"
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-6 pt-10">
          <div className="flex items-center gap-2.5 px-5 py-2.5 bg-emerald-50 text-emerald-700 rounded-full text-[11px] font-bold uppercase tracking-widest border border-emerald-100">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Audit Active
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveSanctuary;
