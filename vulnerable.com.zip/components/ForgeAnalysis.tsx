
import React, { useState } from 'react';
import { analyzeForgeStakes } from '../services/gemini';
import { ForgeResult } from '../types';

interface Props {
  onSaveResult: (result: ForgeResult) => void;
  history: ForgeResult[];
}

const ForgeAnalysis: React.FC<Props> = ({ onSaveResult, history }) => {
  const [dilemma, setDilemma] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ForgeResult | null>(null);

  const handleAnalyze = async () => {
    if (!dilemma.trim()) return;
    setIsLoading(true);
    try {
      const analysis = await analyzeForgeStakes(dilemma);
      const fullResult: ForgeResult = {
        ...analysis,
        id: `forge-${Date.now()}`,
        dilemma,
        timestamp: new Date()
      };
      setResult(fullResult);
      onSaveResult(fullResult);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-12 animate-slide-up max-w-6xl mx-auto pb-20">
      <header className="space-y-4">
        <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-orange-50 text-orange-700 text-[10px] font-black uppercase tracking-widest border border-orange-100">
           <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
           Strategic Audit
        </div>
        <h2 className="text-6xl md:text-8xl font-serif font-bold text-black tracking-tighter leading-none">The <span className="text-zinc-300">Forge</span></h2>
        <p className="text-zinc-500 text-lg font-medium max-w-xl">Deep-tissue analysis of high-stakes integrity decisions.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <section className="bg-white p-12 rounded-[3rem] border border-zinc-100 shadow-xl space-y-10">
           <div className="space-y-4">
             <label className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-400">Input Dilemma</label>
             <textarea 
               value={dilemma}
               onChange={(e) => setDilemma(e.target.value)}
               placeholder="Example: My board is pushing for a toxic hire..."
               className="w-full h-72 bg-zinc-50 border-none rounded-3xl p-8 text-2xl font-serif italic focus:ring-0 focus:bg-zinc-100 transition-all placeholder:text-zinc-200"
             />
           </div>
           <button 
             onClick={handleAnalyze}
             disabled={isLoading || !dilemma.trim()}
             className="w-full py-8 bg-black text-white rounded-[2rem] text-xs font-black uppercase tracking-[0.4em] shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-20"
           >
             {isLoading ? 'Scanning Market Logic...' : 'Analyze Strategic Path'}
           </button>
        </section>

        <section className="space-y-12">
          {isLoading ? (
            <div className="h-full flex flex-col items-center justify-center space-y-8 text-zinc-200 animate-pulse">
               <div className="w-20 h-20 border-4 border-zinc-50 border-t-orange-500 rounded-full animate-spin"></div>
               <p className="text-[10px] font-black uppercase tracking-[0.5em]">Cross-referencing Precedents...</p>
            </div>
          ) : result ? (
            <div className="animate-fade-in space-y-12">
               <div className="grid grid-cols-2 gap-6">
                  <div className="p-8 bg-rose-50 rounded-3xl border border-rose-100 text-center space-y-2">
                    <p className="text-[10px] font-black uppercase tracking-widest text-rose-400">Structural Risk</p>
                    <p className="text-5xl font-serif italic font-bold text-rose-600">{result.riskScore}%</p>
                  </div>
                  <div className="p-8 bg-emerald-50 rounded-3xl border border-emerald-100 text-center space-y-2">
                    <p className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Integrity Gain</p>
                    <p className="text-5xl font-serif italic font-bold text-emerald-600">{result.integrityScore}%</p>
                  </div>
               </div>
               <div className="space-y-6">
                 <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-orange-500">Integrity Pathway</h4>
                 <div className="prose prose-zinc prose-lg text-zinc-600 font-medium leading-relaxed italic">
                   {result.summary}
                 </div>
               </div>
               <div className="space-y-6">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300">Actionable Steps</h4>
                  <div className="space-y-4">
                    {result.actionSteps.map((step, i) => (
                      <div key={i} className="flex gap-4 items-start p-6 bg-white border border-zinc-100 rounded-2xl shadow-sm">
                        <span className="w-6 h-6 shrink-0 bg-black text-white text-[10px] font-black flex items-center justify-center rounded-lg">{i+1}</span>
                        <p className="text-sm font-bold text-black">{step}</p>
                      </div>
                    ))}
                  </div>
               </div>
               {result.precedents.length > 0 && (
                 <div className="space-y-6">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-400">Verified Precedents</h4>
                    <div className="space-y-3">
                      {result.precedents.map((p, i) => (
                        <a key={i} href={p.uri} target="_blank" className="flex items-center justify-between p-5 bg-zinc-50 border border-zinc-100 rounded-2xl hover:bg-black hover:text-white transition-all group">
                          <span className="text-xs font-bold truncate pr-4">{p.title}</span>
                          <svg className="w-4 h-4 opacity-30 group-hover:opacity-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                        </a>
                      ))}
                    </div>
                 </div>
               )}
            </div>
          ) : (
            <div className="space-y-12 h-full">
              <div className="bg-zinc-50/50 border border-zinc-100 border-dashed rounded-[3rem] flex flex-col items-center justify-center p-20 text-center space-y-6">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-sm">
                    <svg className="w-10 h-10 text-zinc-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                </div>
                <p className="text-sm font-bold text-zinc-300 uppercase tracking-[0.4em]">Awaiting Dilemma Analysis</p>
              </div>
              
              {history.length > 0 && (
                <div className="space-y-6">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-400">Archived Audits</h4>
                  <div className="space-y-3">
                    {history.map(item => (
                      <button key={item.id} onClick={() => setResult(item)} className="w-full p-6 bg-white border border-zinc-100 rounded-2xl text-left hover:border-black transition-all shadow-sm flex justify-between items-center">
                        <p className="text-sm font-bold truncate pr-4 italic">"{item.dilemma.slice(0, 40)}..."</p>
                        <span className="text-[10px] font-mono text-zinc-300">{new Date(item.timestamp).toLocaleDateString()}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default ForgeAnalysis;
