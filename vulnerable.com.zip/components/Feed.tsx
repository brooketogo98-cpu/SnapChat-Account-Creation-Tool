
import React, { useState, useEffect, useRef } from 'react';
import { FeedPost, Comment, FeedChannel } from '../types';
import { getMirrorReflection } from '../services/gemini';
import { MOCK_ME } from '../constants';

type SortMode = 'New' | 'Deep' | 'Viral';

const MirrorReport: React.FC<{ posts: FeedPost[] }> = ({ posts }) => {
  const [report, setReport] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateReflection = async () => {
    if (posts.length < 1) return;
    setIsLoading(true);
    try {
      const data = await getMirrorReflection(posts.map(p => p.content));
      setReport(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="mb-12 p-10 bg-zinc-950 text-white rounded-[3rem] border border-white/5 grain-overlay overflow-hidden relative shadow-2xl animate-fade-in">
      <div className="relative z-10 space-y-8">
        <header className="flex justify-between items-center">
          <div className="space-y-1">
            <h3 className="text-[10px] font-black uppercase tracking-[0.5em] text-zinc-500">Subtext Mirror</h3>
            <p className="text-[9px] font-mono text-zinc-600 uppercase">Analysis of {posts.length} disclosures</p>
          </div>
          <button 
            onClick={generateReflection}
            disabled={isLoading || posts.length === 0}
            className="text-[9px] font-black uppercase tracking-widest text-white border border-white/20 px-6 py-3 rounded-2xl hover:bg-white hover:text-black transition-all shadow-lg active:scale-95"
          >
            {isLoading ? 'Scanning Shadows...' : 'Update Reflection'}
          </button>
        </header>

        {report ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 animate-slide-up">
             <div className="space-y-4 p-8 bg-white/5 rounded-[2rem] border border-white/5">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-rose-500">The Shadow Pattern</h4>
                <p className="text-2xl font-serif italic text-zinc-200 leading-snug">"{report.shadowPattern}"</p>
             </div>
             <div className="space-y-4 p-8 bg-white/5 rounded-[2rem] border border-white/5">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Primary Growth Vector</h4>
                <p className="text-2xl font-serif italic text-zinc-200 leading-snug">"{report.growthVector}"</p>
             </div>
          </div>
        ) : (
          <div className="py-12 border-2 border-dashed border-white/5 rounded-[2rem] text-center">
            <p className="text-sm font-medium text-zinc-500 italic">
              {posts.length === 0 
                ? "The Mirror requires data. Contribute truths to generate a report."
                : "Submit for a Spectral Reflection of your recent disclosures."}
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

const PostItem: React.FC<{ 
  post: FeedPost; 
  index: number; 
  onBlock: (handle: string) => void;
  onViewPeer: (handle: string) => void;
}> = ({ post, index, onBlock, onViewPeer }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isUnveiled, setIsUnveiled] = useState(!post.isShrouded);
  const [isResonating, setIsResonating] = useState(false);
  const [isPressing, setIsPressing] = useState(false);
  const pressTimer = useRef<number | null>(null);
  const rippleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), index * 50);
    return () => clearTimeout(timer);
  }, [index]);

  const startPress = (e: React.MouseEvent | React.TouchEvent) => {
    if (isUnveiled) return;
    setIsPressing(true);
    pressTimer.current = window.setTimeout(() => {
      setIsUnveiled(true);
      setIsPressing(false);
    }, 1200); 
  };

  const endPress = () => {
    setIsPressing(false);
    if (pressTimer.current) clearTimeout(pressTimer.current);
  };

  const handleRipple = (e: React.MouseEvent) => {
    if (rippleRef.current) {
      const ripple = document.createElement('span');
      ripple.className = 'ripple-circle animate-ripple';
      const rect = rippleRef.current.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = `${size * 2}px`;
      ripple.style.left = `${e.clientX - rect.left}px`;
      ripple.style.top = `${e.clientY - rect.top}px`;
      rippleRef.current.appendChild(ripple);
      setTimeout(() => ripple.remove(), 800);
    }
    setIsResonating(!isResonating);
  };

  const getChannelStyles = (channel: FeedChannel) => {
    switch (channel) {
      case 'void': return { card: 'bg-zinc-950 text-white border-white/5 grain-overlay shadow-2xl', text: 'text-zinc-200 font-serif italic text-2xl leading-relaxed tracking-tight', authorBg: 'bg-zinc-800 text-zinc-300' };
      case 'forge': return { card: 'bg-white border-zinc-200 shadow-xl ring-1 ring-zinc-100', text: 'text-black font-sans font-bold text-xl leading-snug tracking-tight', authorBg: 'bg-zinc-100 text-zinc-600' };
      case 'mirror': return { card: 'bg-zinc-50 border-zinc-100 italic', text: 'text-zinc-600 font-serif text-xl leading-relaxed', authorBg: 'bg-zinc-200 text-zinc-500' };
      default: return { card: 'bg-white border-zinc-100 shadow-sm', text: 'text-zinc-800 font-serif text-2xl leading-relaxed tracking-tight', authorBg: 'bg-zinc-50 text-zinc-500' };
    }
  };

  const styles = getChannelStyles(post.channel);

  return (
    <article 
      className={`group w-full mb-8 p-10 rounded-[3rem] border relative overflow-hidden transition-all duration-1000 ${styles.card} ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}
      itemScope itemType="https://schema.org/SocialMediaPosting"
    >
      <div ref={rippleRef} className="ripple-container"></div>
      <header className="flex items-center justify-between mb-10 relative z-20">
        <button 
          onClick={() => onViewPeer(post.authorHandle)}
          className="flex items-center gap-5 text-left group/author"
          aria-label={`View profile for ${post.authorName}`}
        >
          <div className={`w-14 h-14 rounded-3xl flex items-center justify-center font-bold text-lg transition-all group-hover/author:scale-110 group-hover/author:rotate-3 shadow-sm ${styles.authorBg}`} aria-hidden="true">{post.authorName.charAt(0)}</div>
          <div itemProp="author" itemScope itemType="https://schema.org/Person">
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] group-hover/author:underline group-hover/author:text-black transition-colors" itemProp="name">{post.authorName}</h4>
            <span className="text-[10px] font-mono text-zinc-400 font-bold" itemProp="alternateName">{post.authorHandle}</span>
          </div>
        </button>
        <button onClick={() => onBlock(post.authorHandle)} className="text-[8px] font-black uppercase tracking-widest text-zinc-300 hover:text-rose-600 transition-colors bg-zinc-50/50 px-3 py-1 rounded-lg">Sever Link</button>
      </header>

      <div className={`witness-shroud select-none ${isUnveiled ? 'unveiled' : ''}`} itemProp="articleBody">
        <p className={styles.text}>{post.content}</p>
      </div>
      
      {!isUnveiled && (
        <div 
          onMouseDown={startPress}
          onMouseUp={endPress}
          onMouseLeave={endPress}
          onTouchStart={startPress}
          onTouchEnd={endPress}
          className="absolute inset-0 flex flex-col items-center justify-center bg-white/10 backdrop-blur-[24px] cursor-pointer group/unveil z-30 transition-all duration-700 hover:backdrop-blur-[12px]"
          aria-label="Disclosure is shrouded. Hold to witness."
        >
          <div className="space-y-6 text-center animate-fade-in">
            <p className="text-[10px] font-black uppercase tracking-[0.6em] text-black/40">Shrouded Disclosure</p>
            <div className={`text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-500 ${isPressing ? 'text-black scale-110' : 'text-zinc-500 group-hover/unveil:text-black'}`}>
               {isPressing ? 'Verifying Commitment...' : 'Hold to Witness Truth'}
            </div>
            {isPressing && (
              <div className="w-56 h-1 bg-black/5 mx-auto rounded-full overflow-hidden shadow-inner ring-1 ring-black/5">
                <div className="h-full bg-black animate-shroud-bar"></div>
              </div>
            )}
          </div>
        </div>
      )}

      <footer className="relative z-20 pt-8 mt-10 border-t border-zinc-100 flex items-center justify-between">
        <div className="flex gap-8">
          <button onClick={handleRipple} className={`flex items-center gap-3 text-[10px] font-black uppercase tracking-widest transition-all ${isResonating ? 'text-black scale-105' : 'text-zinc-400 hover:text-black'}`}>
            <svg className={`w-5 h-5 transition-transform ${isResonating ? 'scale-125' : ''}`} fill={isResonating ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
            <span className="font-mono">{(post.witnessCount || 0) + (isResonating ? 1 : 0)}</span>
          </button>
        </div>
        <div className="flex items-center gap-4">
          {post.isModelCitizen && <span className="text-[8px] font-black uppercase tracking-widest text-emerald-500 border border-emerald-100 px-3 py-1 rounded-lg">Model Citizen</span>}
          <time className="text-[9px] font-black text-zinc-300 uppercase tracking-widest" itemProp="datePublished" dateTime={new Date(post.timestamp).toISOString()}>{new Date(post.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}</time>
        </div>
      </footer>
    </article>
  );
};

interface FeedProps {
  posts: FeedPost[];
  channel: FeedChannel;
  blockedUserHandles: string[];
  onBlockUser: (handle: string) => void;
  onAddPost: (content: string, channel: FeedChannel) => void;
  onEnterSanctuary?: () => void;
  onViewPeer: (handle: string) => void;
}

const Feed: React.FC<FeedProps> = ({ posts, channel, blockedUserHandles, onBlockUser, onAddPost, onViewPeer }) => {
  const [composeText, setComposeText] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('New');
  const [isInputFocused, setIsInputFocused] = useState(false);

  const getHeaderInfo = (chan: FeedChannel) => {
    switch (chan) {
      case 'void': return { title: 'The Void', desc: 'Catharsis without echo.' };
      case 'forge': return { title: 'The Forge', desc: 'Strategic Integrity Audit.' };
      case 'mirror': return { title: 'The Mirror', desc: 'Personal Reflection Vault.' };
      default: return { title: 'The Garden', desc: 'Verified Peer Narratives.' };
    }
  };

  const header = getHeaderInfo(channel);
  const userOwnPosts = posts.filter(p => p.authorHandle === MOCK_ME.legalHandle);

  const filteredPosts = posts
    .filter(p => p.channel === channel && !blockedUserHandles.includes(p.authorHandle))
    .sort((a, b) => {
      if (sortMode === 'New') return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      if (sortMode === 'Deep') return (b.witnessCount || 0) - (a.witnessCount || 0);
      return 0;
    });

  return (
    <div className="space-y-16 max-w-5xl mx-auto">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-10 pb-6 border-b border-zinc-100">
        <div className="space-y-4">
          <h2 className="text-6xl md:text-7xl font-serif font-bold text-black tracking-tighter leading-none">{header.title}</h2>
          <p className="text-zinc-400 text-[11px] font-black uppercase tracking-[0.5em]">{header.desc}</p>
        </div>
        <div className="flex gap-1 bg-zinc-100/50 p-2 rounded-2xl backdrop-blur-sm border border-zinc-100">
          {(['New', 'Deep'] as SortMode[]).map(mode => (
            <button key={mode} onClick={() => setSortMode(mode)} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${sortMode === mode ? 'bg-white text-black shadow-lg ring-1 ring-black/5' : 'text-zinc-400 hover:text-black'}`}>{mode}</button>
          ))}
        </div>
      </header>

      {channel === 'mirror' && <MirrorReport posts={userOwnPosts} />}

      <section className={`bg-white rounded-[3rem] border p-8 transition-all duration-700 ease-in-out ${isInputFocused ? 'ring-4 ring-black/5 shadow-3xl scale-[1.02] border-black' : 'border-zinc-100 shadow-sm'}`} aria-labelledby="disclosure-form-title">
        <h3 id="disclosure-form-title" className="sr-only">Add New Disclosure</h3>
        <textarea 
          value={composeText}
          onFocus={() => setIsInputFocused(true)}
          onChange={(e) => setComposeText(e.target.value)}
          placeholder={`Contribute a truth to ${header.title}...`}
          className={`w-full bg-transparent border-none focus:ring-0 text-2xl font-serif italic resize-none transition-all placeholder:text-zinc-200 ${isInputFocused ? 'min-h-[180px]' : 'min-h-[48px]'}`}
          aria-label="Truth disclosure input"
        />
        {isInputFocused && (
          <div className="flex justify-between items-center pt-8 border-t border-zinc-50 animate-fade-in">
            <p className="text-[9px] font-black uppercase tracking-widest text-zinc-300">Absolute transparency required</p>
            <div className="flex gap-4">
              <button onClick={() => { setIsInputFocused(false); setComposeText(''); }} className="px-8 py-4 text-[10px] font-black uppercase text-zinc-400 hover:text-black transition-colors">Cancel</button>
              <button 
                onClick={() => { onAddPost(composeText, channel); setComposeText(''); setIsInputFocused(false); }} 
                disabled={!composeText.trim()}
                className="px-10 py-4 bg-black text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl disabled:opacity-20 active:scale-95 transition-all"
              >
                Broadcast disclosure
              </button>
            </div>
          </div>
        )}
      </section>

      <div className="grid grid-cols-1 gap-4">
        {filteredPosts.length === 0 ? (
          <div className="py-32 text-center space-y-6">
             <div className="w-20 h-20 bg-zinc-50 rounded-[2.5rem] mx-auto flex items-center justify-center border border-zinc-100" aria-hidden="true">
               <svg className="w-10 h-10 text-zinc-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
             </div>
             <div className="space-y-2">
               <p className="text-[11px] font-black uppercase tracking-[0.4em] text-zinc-300">Channel Ledger Clear</p>
               <p className="text-sm font-medium text-zinc-400 italic">Be the first to establish frequency in this space.</p>
             </div>
          </div>
        ) : (
          filteredPosts.map((post, idx) => <PostItem key={post.id} post={post} index={idx} onBlock={onBlockUser} onViewPeer={onViewPeer} />)
        )}
      </div>
    </div>
  );
};

export default Feed;
