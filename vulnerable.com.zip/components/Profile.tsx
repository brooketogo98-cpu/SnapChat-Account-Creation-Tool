
import React, { useState, useRef } from 'react';
import { VulnerableUser, ProfileSectionConfig, FeedPost } from '../types';
import SEO from './SEO';

const PrivacyShroud: React.FC<{ children: React.ReactNode; label: string }> = ({ children, label }) => {
  const [isUnveiled, setIsUnveiled] = useState(false);
  const [isPressing, setIsPressing] = useState(false);
  const pressTimer = useRef<number | null>(null);

  const startPress = () => {
    setIsPressing(true);
    pressTimer.current = window.setTimeout(() => {
      setIsUnveiled(true);
      setIsPressing(false);
    }, 1200);
  };

  const endPress = () => {
    setIsPressing(false);
    if (pressTimer.current) clearTimeout(pressTimer.current);
  };

  if (isUnveiled) return <div className="animate-fade-in">{children}</div>;

  return (
    <section 
      onMouseDown={startPress}
      onMouseUp={endPress}
      onMouseLeave={endPress}
      onTouchStart={startPress}
      onTouchEnd={endPress}
      className="relative min-h-[240px] rounded-[3rem] glass border border-zinc-200 flex flex-col items-center justify-center p-10 cursor-pointer group transition-all duration-700 hover:border-black"
      aria-label={`Private disclosure: ${label}`}
    >
      <div className="text-center space-y-6">
        <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-black/40 group-hover:text-black transition-colors">{label}</h3>
        <div className="space-y-4">
           <div className={`text-[11px] font-black uppercase tracking-widest transition-colors ${isPressing ? 'text-black' : 'text-zinc-300'}`}>
             {isPressing ? 'Verifying Intent...' : 'Hold to Unveil Disclosure'}
           </div>
           {isPressing && (
             <div className="w-48 h-1 bg-zinc-100 mx-auto overflow-hidden rounded-full">
               <div className="h-full bg-black animate-shroud-bar"></div>
             </div>
           )}
        </div>
      </div>
    </section>
  );
};

const SectionCard: React.FC<{ config: ProfileSectionConfig; user: VulnerableUser; posts: FeedPost[]; onWitness: (id: string) => void; isMe: boolean }> = ({ config, user, posts, onWitness, isMe }) => {
  const renderContent = () => {
    switch (config.type) {
      case 'bio':
        return (
          <div className="space-y-10">
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300 border-b border-zinc-50 pb-6">Narrative Path</h4>
            <p className="text-4xl md:text-5xl font-serif font-bold text-black tracking-tighter leading-tight">
              {user.bio}
            </p>
            <div className="pt-8 space-y-4">
              <h5 className="text-[10px] font-black uppercase text-zinc-400">Recent Disclosures</h5>
              <div className="space-y-3">
                {posts.slice(0, 3).map(p => (
                  <article key={p.id} className="p-4 bg-zinc-50 rounded-xl border border-zinc-100 italic font-serif text-lg">
                    "{p.content}"
                  </article>
                ))}
              </div>
            </div>
          </div>
        );
      case 'stakes':
        return (
          <div className="space-y-10">
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300 border-b border-zinc-50 pb-6">Verified Stakes</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {user.verifiedStakes.map((stake) => (
                <article key={stake.id} className="p-10 border border-zinc-100 rounded-[2.5rem] bg-white shadow-sm space-y-6 group/stake relative overflow-hidden">
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-black uppercase tracking-widest text-black bg-zinc-50 px-4 py-1.5 rounded-full inline-block">
                      {stake.label}
                    </span>
                    {!isMe && (
                      <button 
                        onClick={() => onWitness(stake.id)}
                        className="opacity-0 group-hover/stake:opacity-100 transition-opacity bg-black text-white px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest hover:scale-110 active:scale-95 shadow-xl"
                      >
                        Witness Stake
                      </button>
                    )}
                  </div>
                  <h5 className="text-xl font-bold text-black leading-tight tracking-tight">{stake.description}</h5>
                  <div className="flex items-center gap-2 pt-4 border-t border-zinc-50 text-[9px] font-black text-zinc-300 uppercase tracking-widest">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    {(stake.witnesses?.length || 0)} Peers Witnessed
                  </div>
                </article>
              ))}
            </div>
          </div>
        );
      case 'shards':
        return (
          <div className="space-y-12">
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300 border-b border-zinc-50 pb-6">Narrative Shards</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="space-y-4">
                <h5 className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Regrets</h5>
                <div className="space-y-2">
                  {user.profileSections.regrets.map((r, i) => (
                    <p key={i} className="text-sm italic font-serif text-zinc-600">"{r}"</p>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h5 className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Hobbies</h5>
                <div className="flex flex-wrap gap-2">
                  {user.profileSections.hobbies.map((h, i) => (
                    <span key={i} className="px-3 py-1 bg-zinc-50 border border-zinc-100 rounded-lg text-[10px] font-bold text-black">{h}</span>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h5 className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Entrepreneurship</h5>
                <p className="text-sm font-medium leading-relaxed">{user.profileSections.entrepreneurship}</p>
              </div>
            </div>
          </div>
        );
      default: return null;
    }
  };

  if (config.tier === 'shrouded' && !isMe) {
    return <PrivacyShroud label={config.label}>{renderContent()}</PrivacyShroud>;
  }
  return <section className="py-12 border-b border-zinc-50 last:border-none">{renderContent()}</section>;
};

const Profile: React.FC<{ user: VulnerableUser; posts: FeedPost[]; onWitnessStake: (userId: string, stakeId: string) => void; isMe: boolean; onBack?: () => void }> = ({ user, posts, onWitnessStake, isMe, onBack }) => {
  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": user.displayName,
    "alternateName": user.legalHandle,
    "description": user.bio,
    "url": `https://vulnerable.com/p/${user.legalHandle.replace('@', '')}`,
    "knowsAbout": user.verifiedAttributes
  };

  return (
    <div className="space-y-16 lg:space-y-24 animate-slide-up">
      <SEO 
        title={`${user.displayName} (@${user.legalHandle})`} 
        description={user.bio} 
        schema={personSchema}
        canonical={`https://vulnerable.com/p/${user.legalHandle.replace('@', '')}`}
      />
      {!isMe && onBack && (
        <button 
          onClick={onBack}
          className="flex items-center gap-3 text-zinc-400 hover:text-black transition-colors"
          aria-label="Return to activity feed"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          <span className="text-[10px] font-black uppercase tracking-widest">Back to Feed</span>
        </button>
      )}

      <header className="space-y-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-12 border-b border-zinc-100 pb-20">
          <div className="space-y-10">
            <div className="w-24 h-24 rounded-[2.5rem] bg-black text-white flex items-center justify-center text-4xl font-serif font-bold shadow-2xl rotate-3" aria-hidden="true">
              {user.displayName.charAt(0)}
            </div>
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <h1 className="text-7xl md:text-8xl font-serif font-bold text-black tracking-tighter leading-none">
                  {user.displayName}
                </h1>
                {isMe && <span className="px-3 py-1 bg-black text-white rounded-lg text-[8px] font-black uppercase">You</span>}
              </div>
              <div className="flex flex-wrap items-center gap-6">
                <span className="text-[10px] font-black uppercase tracking-[0.5em] text-zinc-300">Identity Verified</span>
                <span className="px-5 py-2 bg-zinc-100 rounded-full text-xs font-bold font-mono text-black">
                  {user.legalHandle}
                </span>
              </div>
            </div>
          </div>
          <div className="flex gap-4">
             <div className="text-center p-6 bg-zinc-50 rounded-3xl min-w-[120px]">
                <h2 className="text-[9px] font-black text-zinc-400 uppercase mb-1">Truth Equity</h2>
                <p className="text-2xl font-serif font-bold">{user.truthEquity.score}</p>
             </div>
             <div className="text-center p-6 bg-zinc-50 rounded-3xl min-w-[120px]">
                <h2 className="text-[9px] font-black text-zinc-400 uppercase mb-1">Disclosures</h2>
                <p className="text-2xl font-serif font-bold">{posts.length}</p>
             </div>
          </div>
        </div>
      </header>

      <div className="space-y-12 lg:space-y-20">
        {user.profileLayout
          .sort((a, b) => a.order - b.order)
          .filter(c => c.isVisible)
          .map((config) => (
            <SectionCard key={config.id} config={config} user={user} posts={posts} onWitness={(stakeId) => onWitnessStake(user.id, stakeId)} isMe={isMe} />
          ))
        }
      </div>
    </div>
  );
};

export default Profile;
