
import * as React from 'react';
import { useState, useRef, useEffect } from 'react';
import { User, Message, Pod } from '../types';
import { getFacilitatorPrompt, analyzeGroupFrequency } from '../services/gemini';

interface Props {
  user: User;
  pod: Pod;
  onSendMessage: (podId: string, content: string, isFacilitator?: boolean) => void;
}

const FrequencyVisualizer: React.FC<{ heatmapValue: number; frequency: string }> = ({ heatmapValue, frequency }) => {
  return (
    <div className="flex items-center gap-4 px-6 py-3 bg-zinc-50 rounded-2xl border border-zinc-100 shadow-inner">
      <div className="relative w-8 h-8 flex items-center justify-center">
        {/* Pulsing Heatmap Orb */}
        <div 
          className="absolute inset-0 rounded-full blur-md transition-all duration-1000"
          style={{ 
            backgroundColor: heatmapValue > 0.7 ? '#F43F5E' : heatmapValue > 0.4 ? '#F59E0B' : '#10B981',
            opacity: 0.2 + (heatmapValue * 0.4),
            transform: `scale(${1 + heatmapValue * 0.5})`
          }}
        />
        <div 
          className="relative w-3 h-3 rounded-full transition-all duration-700"
          style={{ 
            backgroundColor: heatmapValue > 0.7 ? '#E11D48' : heatmapValue > 0.4 ? '#D97706' : '#059669',
            boxShadow: `0 0 ${10 + heatmapValue * 20}px ${heatmapValue > 0.7 ? '#E11D48' : '#059669'}`
          }}
        />
      </div>
      <div>
        <p className="text-[8px] font-black uppercase tracking-[0.3em] text-zinc-400">Group Frequency</p>
        <p className="text-[10px] font-black uppercase tracking-widest text-black">{frequency || 'Stable'}</p>
      </div>
    </div>
  );
};

const PodView: React.FC<Props> = ({ user, pod, onSendMessage }) => {
  const [input, setInput] = useState('');
  const [isFacilitating, setIsFacilitating] = useState(false);
  const [groupStats, setGroupStats] = useState({ frequency: 'Syncing', resonanceScore: 0, heatmapValue: 0.2 });
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    
    // Analyze frequency whenever messages update (every 3 messages)
    if (pod.messages.length > 0 && pod.messages.length % 3 === 0) {
      runFrequencySweep();
    }
  }, [pod.messages]);

  const runFrequencySweep = async () => {
    const textHistory = pod.messages.slice(-5).map(m => m.content);
    try {
      const stats = await analyzeGroupFrequency(textHistory);
      setGroupStats(stats);
    } catch (e) {
      console.error("Frequency sweep failed", e);
    }
  };

  const handleSend = () => {
    if (!input.trim()) return;
    onSendMessage(pod.id, input);
    setInput('');
  };

  const handleTriggerFacilitator = async () => {
    if (isFacilitating) return;
    setIsFacilitating(true);
    
    const history = pod.messages
      .filter(m => !m.isFacilitator)
      .slice(-10)
      .map(m => `${m.senderName}: ${m.content}`)
      .join('\n');
      
    try {
      const prompt = await getFacilitatorPrompt(history);
      if (prompt) {
        onSendMessage(pod.id, prompt, true);
      }
    } catch (error) {
      console.error("Facilitator error:", error);
    } finally {
      setIsFacilitating(false);
    }
  };

  return (
    <div className="flex flex-col h-[70vh] bg-white border border-zinc-200 rounded-[2.5rem] overflow-hidden shadow-2xl relative animate-slide-up">
      <div className="p-8 border-b border-zinc-100 flex items-center justify-between bg-white/80 backdrop-blur-md z-10 shrink-0">
        <div className="flex items-center gap-6">
          <div className="min-w-0 pr-4">
            <div className="flex items-center gap-3 mb-1">
               <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></div>
               <h2 className="text-xl font-bold text-vulnerable-text truncate tracking-tight">{pod.name}</h2>
            </div>
            <p className="text-[11px] text-zinc-400 font-bold uppercase tracking-[0.2em] truncate">{pod.topic}</p>
          </div>
          <FrequencyVisualizer heatmapValue={groupStats.heatmapValue} frequency={groupStats.frequency} />
        </div>
        <div className="flex -space-x-3 shrink-0">
          {pod.members.map(m => (
            <div key={m.id} className="w-10 h-10 rounded-xl bg-zinc-50 border-2 border-white flex items-center justify-center text-xs font-bold text-vulnerable-text shadow-sm" title={m.name}>
              {m.name.charAt(0)}
            </div>
          ))}
          <div className="w-10 h-10 rounded-xl bg-black border-2 border-white flex items-center justify-center text-xs font-bold text-white shadow-lg ring-4 ring-zinc-50">AI</div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 md:p-12 space-y-10 scroll-smooth no-scrollbar bg-zinc-50/30">
        {pod.messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.isFacilitator ? 'items-center py-10' : msg.senderId === user.id ? 'items-end' : 'items-start'}`}>
            {msg.isFacilitator ? (
              <div className="w-full max-w-2xl text-center space-y-6 px-6">
                <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-bold uppercase tracking-[0.3em] mb-2 border border-blue-100 shadow-sm">
                  Counseling Protocol
                </div>
                <p className="text-vulnerable-text font-serif italic text-2xl md:text-3xl leading-relaxed tracking-tight">"{msg.content}"</p>
              </div>
            ) : (
              <div className={`max-w-[85%] md:max-w-[70%] space-y-2`}>
                <div className={`flex items-center gap-3 px-1 ${msg.senderId === user.id ? 'flex-row-reverse' : ''}`}>
                  <span className="text-[10px] font-bold text-black uppercase tracking-widest opacity-40">{msg.senderName}</span>
                  <span className="text-[10px] text-zinc-300 font-bold uppercase tracking-widest">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className={`p-6 rounded-3xl text-sm leading-relaxed tracking-tight shadow-sm border ${
                  msg.senderId === user.id ? 'bg-black text-white border-black rounded-tr-none' : 'bg-white text-black border-zinc-200 rounded-tl-none font-medium'
                }`}>
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            )}
          </div>
        ))}
        {isFacilitating && (
          <div className="flex flex-col items-center py-10 animate-pulse text-zinc-300 text-[10px] font-black uppercase tracking-widest">
            AI Analyzing Continuity...
          </div>
        )}
      </div>

      <div className="p-6 md:p-10 border-t border-zinc-100 bg-white">
        <div className="flex items-center gap-6">
          <button onClick={handleTriggerFacilitator} disabled={isFacilitating} className="shrink-0 w-14 h-14 rounded-2xl bg-zinc-50 border border-zinc-100 flex items-center justify-center hover:bg-zinc-100 transition-all disabled:opacity-30">
            <svg className={`w-6 h-6 ${isFacilitating ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </button>
          <div className="flex-1 relative">
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Contribute to the discussion..." className="w-full bg-zinc-50 border-none rounded-3xl px-8 py-5 text-base focus:bg-white transition-all shadow-inner" />
            <button onClick={handleSend} disabled={!input.trim()} className={`absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-2xl ${input.trim() ? 'bg-black text-white shadow-xl' : 'text-zinc-200'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PodView;
