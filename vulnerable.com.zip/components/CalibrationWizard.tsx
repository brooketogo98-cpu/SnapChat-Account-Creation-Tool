
import React, { useState } from 'react';
import { runCalibrationAI } from '../services/gemini';
import { CalibrationData } from '../types';

interface Props {
  onComplete: (data: CalibrationData) => void;
  onCancel: () => void;
}

const CalibrationWizard: React.FC<Props> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [feelings, setFeelings] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const aiData = await runCalibrationAI(feelings);
      setResult(aiData);
      setStep(2);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const finish = () => {
    onComplete({
      alignment: result.alignment,
      dominantEmotion: result.emotion,
      intent: result.intent,
      timestamp: new Date(),
      aiInsight: result.insight
    });
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-white/90 backdrop-blur-xl p-4 animate-fade-in">
      <div className="bg-white border border-zinc-200 rounded-[3rem] w-full max-w-2xl overflow-hidden shadow-2xl">
        <div className="p-10 md:p-14 space-y-10">
          <header className="flex justify-between items-center">
            <h2 className="text-3xl font-serif italic text-black">Morning <span className="text-zinc-300">Calibration</span></h2>
            <button onClick={onCancel} className="p-3 bg-zinc-50 rounded-2xl hover:bg-zinc-100 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </header>

          {step === 1 ? (
            <div className="space-y-8">
              <div className="space-y-4">
                <p className="text-xs font-black uppercase tracking-[0.4em] text-zinc-400">Step 1: Raw Input</p>
                <textarea 
                  value={feelings}
                  onChange={(e) => setFeelings(e.target.value)}
                  placeholder="How is your internal frequency today? Be specific..."
                  className="w-full h-48 bg-zinc-50 border-none rounded-2xl p-6 text-xl font-serif italic focus:ring-0 focus:bg-zinc-100 transition-all placeholder:text-zinc-200"
                />
              </div>
              <button 
                onClick={handleAnalyze}
                disabled={isAnalyzing || !feelings.trim()}
                className="w-full py-6 bg-black text-white rounded-2xl text-xs font-black uppercase tracking-[0.4em] shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-20"
              >
                {isAnalyzing ? 'Syncing Frequency...' : 'Submit Calibration'}
              </button>
            </div>
          ) : (
            <div className="space-y-10 animate-slide-up">
              <div className="grid grid-cols-2 gap-6">
                <div className="p-8 bg-zinc-50 rounded-3xl text-center space-y-2">
                  <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Alignment</p>
                  <p className="text-4xl font-serif italic font-bold text-black">{result.alignment}%</p>
                </div>
                <div className="p-8 bg-zinc-50 rounded-3xl text-center space-y-2">
                  <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Emotion</p>
                  <p className="text-4xl font-serif italic font-bold text-black">{result.emotion}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-black">Truth Intent for Today</h4>
                <div className="p-8 border border-zinc-100 rounded-3xl bg-white shadow-sm italic text-xl font-serif text-zinc-600">
                  "{result.intent}"
                </div>
              </div>

              <div className="p-8 bg-black text-white rounded-3xl space-y-2 grain-overlay relative">
                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500">AI Insight</p>
                <p className="text-sm font-medium leading-relaxed">{result.insight}</p>
              </div>

              <button 
                onClick={finish}
                className="w-full py-6 bg-black text-white rounded-2xl text-xs font-black uppercase tracking-[0.4em] shadow-xl hover:scale-[1.02] transition-all"
              >
                Commit to Alignment
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CalibrationWizard;
