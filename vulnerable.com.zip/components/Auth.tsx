
import React, { useState } from 'react';

interface AuthProps {
  onLogin: (name: string, handle: string) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate a high-integrity verification handshake
    setTimeout(() => {
      onLogin(name || 'Hunter', handle || '@HunterCovert111');
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 grain-overlay relative overflow-hidden">
      {/* Background Decorative Element */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-zinc-50 rounded-full blur-[120px] opacity-50"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-zinc-50 rounded-full blur-[120px] opacity-50"></div>

      <div className="w-full max-w-md space-y-12 relative z-10 animate-fade-in">
        <header className="text-center space-y-4">
          <div className="w-16 h-16 bg-black rounded-3xl mx-auto flex items-center justify-center text-white font-serif font-bold text-3xl shadow-2xl rotate-3 mb-8">
            V
          </div>
          <h1 className="text-4xl font-serif italic text-black tracking-tight">
            {isLogin ? 'Verified Access' : 'Identity Enrollment'}
          </h1>
          <p className="text-zinc-400 text-[10px] font-black uppercase tracking-[0.4em]">
            {isLogin ? 'Resuming the Truth Protocol' : 'Establishing a new Ledger of Integrity'}
          </p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400 ml-2">Legal Identity</label>
                <input
                  required
                  type="text"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-100 rounded-2xl px-6 py-4 text-sm focus:ring-1 focus:ring-black outline-none transition-all"
                />
              </div>
            )}
            <div className="space-y-2">
              <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400 ml-2">Handle Citation</label>
              <input
                required
                type="text"
                placeholder="@username"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-100 rounded-2xl px-6 py-4 text-sm focus:ring-1 focus:ring-black outline-none transition-all font-mono"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400 ml-2">Integrity Key</label>
              <input
                required
                type="password"
                placeholder="••••••••"
                className="w-full bg-zinc-50 border border-zinc-100 rounded-2xl px-6 py-4 text-sm focus:ring-1 focus:ring-black outline-none transition-all"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-5 bg-black text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.4em] shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50"
          >
            {isLoading ? 'Encrypting Handshake...' : isLogin ? 'Authenticate' : 'Initiate Verification'}
          </button>
        </form>

        <footer className="text-center space-y-6">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-black transition-colors"
          >
            {isLogin ? "Need to enroll a new identity?" : "Already verified? Resume access"}
          </button>

          <div className="pt-8 border-t border-zinc-50 flex flex-col items-center gap-4">
             <div className="flex items-center gap-2 opacity-30">
               <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
               <span className="text-[8px] font-black uppercase tracking-[0.3em]">End-to-End Truth Encrypted</span>
             </div>
             <p className="text-[9px] text-zinc-300 max-w-[240px] leading-relaxed">
               By accessing Vulnerable, you commit to radical honesty and non-judgmental listening within the peer network.
             </p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default Auth;
