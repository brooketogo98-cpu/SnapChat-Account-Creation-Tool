
import React, { useState } from 'react';
import { VulnerableUser, IdentityStatus } from '../types';

interface Props {
  user: VulnerableUser;
  onVerify: (attribute: string) => void;
}

const Gatekeeper: React.FC<Props> = ({ user, onVerify }) => {
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const verificationMethods = [
    { 
      id: 'LinkedIn Identity', 
      name: 'Identity Check', 
      desc: 'Verify government ID and real-world identity via professional signatures.',
      status: user.verifiedAttributes.includes('LinkedIn Identity') ? 'VERIFIED' : 'UNVERIFIED'
    },
    { 
      id: 'Crunchbase Listing', 
      name: 'Status Verification', 
      desc: 'Verify professional standing and organizational role through network audit.',
      status: user.verifiedAttributes.includes('Crunchbase Listing') ? 'VERIFIED' : 'UNVERIFIED'
    },
    { 
      id: 'HNW Status', 
      name: 'Asset Attestation', 
      desc: 'Confirm net worth threshold (> $5M) through high-integrity handshakes.',
      status: user.verifiedAttributes.includes('HNW Status') ? 'VERIFIED' : 'UNVERIFIED'
    }
  ];

  const handleVerifyClick = (id: string) => {
    setLoadingId(id);
    // Simulate complex verification process
    setTimeout(() => {
      onVerify(id);
      setLoadingId(null);
    }, 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-12 py-6">
      <div className="text-center space-y-4 max-w-xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-serif italic text-black leading-tight tracking-tight">The <span className="text-zinc-300">Gatekeeper</span> Protocol</h2>
        <p className="text-zinc-500 text-lg font-medium">
          Verify your real-world status to access high-stakes pods and the professional archive.
        </p>
      </div>

      <div className="space-y-4">
        {verificationMethods.map((method, idx) => (
          <div key={method.id} className={`p-6 md:p-8 rounded-3xl border transition-all duration-500 ${method.status === 'VERIFIED' ? 'bg-emerald-50 border-emerald-100' : 'bg-white border-zinc-100 shadow-sm'}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
              <div className="flex items-center gap-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl ${method.status === 'VERIFIED' ? 'bg-emerald-500 text-white' : 'bg-zinc-50 text-zinc-300'}`}>
                  {idx + 1}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-black">{method.name}</h3>
                  <p className="text-sm text-zinc-400 font-medium">{method.desc}</p>
                </div>
              </div>
              <div className="shrink-0">
                {method.status === 'VERIFIED' ? (
                  <span className="flex items-center gap-1.5 text-emerald-600 font-black text-[10px] uppercase tracking-widest bg-white border border-emerald-100 px-4 py-2 rounded-full">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                    Fully Verified
                  </span>
                ) : (
                  <button 
                    onClick={() => handleVerifyClick(method.id)}
                    disabled={loadingId === method.id}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-black text-white text-xs font-black uppercase tracking-widest hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                  >
                    {loadingId === method.id ? 'Verifying...' : 'Verify Now'}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="p-8 md:p-10 rounded-3xl bg-zinc-50 border border-zinc-100 text-center space-y-4 shadow-sm">
        <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em] mb-2">Integrity Status</h4>
        <div className="flex justify-center gap-8">
           <div className="text-center">
             <p className="text-[8px] font-black uppercase tracking-widest text-zinc-300">Level</p>
             <p className="text-xl font-bold">{user.identityStatus}</p>
           </div>
           <div className="text-center border-l border-zinc-200 pl-8">
             <p className="text-[8px] font-black uppercase tracking-widest text-zinc-300">Attributes</p>
             <p className="text-xl font-bold">{user.verifiedAttributes.length}</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Gatekeeper;
