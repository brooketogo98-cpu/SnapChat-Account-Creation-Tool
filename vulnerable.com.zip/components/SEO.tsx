
import React, { useEffect } from 'react';

interface SEOProps {
  title: string;
  description?: string;
  canonical?: string;
  type?: string;
  schema?: object;
}

const SEO: React.FC<SEOProps> = ({ 
  title, 
  description = "A high-integrity social network based on truth and radical honesty.", 
  canonical = "https://vulnerable.com", 
  type = "website",
  schema
}) => {
  useEffect(() => {
    // Update basic meta
    document.title = `${title} | Vulnerable`;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.setAttribute('content', description);
    
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', title);
    
    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute('content', window.location.href);

    // Update canonical
    let link: HTMLLinkElement | null = document.querySelector('link[rel="canonical"]');
    if (!link) {
      link = document.createElement('link');
      link.setAttribute('rel', 'canonical');
      document.head.appendChild(link);
    }
    link.setAttribute('href', canonical);

    // Inject dynamic JSON-LD
    if (schema) {
      const existingScript = document.getElementById('dynamic-json-ld');
      if (existingScript) existingScript.remove();
      
      const script = document.createElement('script');
      script.id = 'dynamic-json-ld';
      script.type = 'application/ld+json';
      script.text = JSON.stringify(schema);
      document.head.appendChild(script);
    }

    return () => {
      const existingScript = document.getElementById('dynamic-json-ld');
      if (existingScript) existingScript.remove();
    };
  }, [title, description, canonical, schema]);

  return null;
};

export default SEO;
