
import * as React from 'react';
import { useState } from 'react';
import { VulnerableUser, AlignmentRequest } from '../types';

interface Props {
  user: VulnerableUser;
  onOpenCalibration: () => void;
  alignmentRequests: AlignmentRequest[];
}

const PulseDashboard: React.FC<Props> = ({ user, onOpenCalibration, alignmentRequests }) => {
  const [ledgerTab, setLedgerTab] = useState<'alignments' | 'equity'>('equity');

  return (
    <div className="space-y-12 lg:space-y-16 animate-slide-up pb-20 max-w-6xl mx-auto">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-black text-white rounded-lg text-[9px] font-black uppercase tracking-widest">
            Audit Ledger v4.5
          </div>
          <h2 className="text-6xl lg:text-8xl font-serif font-bold text-black tracking-tighter leading-none">Internal <span className="text-zinc-300">Pulse</span></h2>
          <p className="text-zinc-500 text-sm font-bold uppercase tracking-[0.4em]">The architecture of your verified development.</p>
        </div>
        <div className="flex gap-4">
           <div className="p-6 bg-white border border-zinc-100 rounded-3xl shadow-sm text-center min-w-[120px] lg:min-w-[140px]">
             <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 mb-2">Equity Rank</p>
             <p className="text-2xl lg:text-3xl font-serif italic font-bold text-black">{user.truthEquity.level}</p>
           </div>
           <div className="p-6 bg-white border border-zinc-100 rounded-3xl shadow-sm text-center min-w-[120px] lg:min-w-[140px]">
             <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 mb-2">Percentile</p>
             <p className="text-2xl lg:text-3xl font-serif italic font-bold text-black">{user.truthEquity.percentile}%</p>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-10">
           <section className="bg-white rounded-[2rem] lg:rounded-[3rem] p-8 lg:p-12 border border-zinc-100 shadow-xl space-y-10 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 lg:p-12">
                <div className="flex items-center gap-2 text-emerald-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                  <span className="text-xs font-black">+{user.truthEquity.recentGrowth}% growth</span>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-2xl font-bold tracking-tight text-black">Alignment Velocity</h3>
                <div className="h-60 lg:h-72 flex items-end gap-2 lg:gap-3 pt-12">
                  {user.calibrationHistory.map((cal, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-4 group">
                        <div 
                          className="w-full bg-zinc-100 rounded-xl lg:rounded-2xl group-hover:bg-black transition-all relative overflow-hidden cursor-help" 
                          style={{ height: `${cal.alignment}%` }}
                          title={cal.aiInsight}
                        >
                          <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/5 to-transparent"></div>
                        </div>
                        <span className="text-[8px] lg:text-[9px] font-black uppercase tracking-widest text-zinc-300">{new Date(cal.timestamp).toLocaleDateString([], { weekday: 'short' })}</span>
                    </div>
                  ))}
                </div>
              </div>
           </section>

           <section className="bg-white border border-zinc-100 rounded-[2rem] lg:rounded-[3rem] p-8 lg:p-12 space-y-8">
              <div className="flex items-center justify-between border-b border-zinc-50 pb-6">
                <div className="flex gap-6">
                  <button onClick={() => setLedgerTab('equity')} className={`text-[10px] font-black uppercase tracking-[0.4em] transition-colors ${ledgerTab === 'equity' ? 'text-black' : 'text-zinc-300'}`}>Equity Ledger</button>
                  <button onClick={() => setLedgerTab('alignments')} className={`text-[10px] font-black uppercase tracking-[0.4em] transition-colors ${ledgerTab === 'alignments' ? 'text-black' : 'text-zinc-300'}`}>Alignment Requests</button>
                </div>
              </div>

              {ledgerTab === 'alignments' ? (
                <div className="space-y-4 pt-4">
                  {alignmentRequests.length === 0 ? (
                    <p className="text-sm font-medium text-zinc-400 italic">No active requests found in the ledger.</p>
                  ) : (
                    alignmentRequests.map(req => (
                      <div key={req.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-6 bg-zinc-50 rounded-3xl border border-zinc-100 gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-2xl bg-black text-white flex items-center justify-center font-bold text-xs">{req.fromUserName?.charAt(0)}</div>
                          <div>
                            <p className="text-sm font-bold text-black">Inbound from {req.fromUserName}</p>
                            <p className="text-[9px] font-black uppercase text-zinc-400 tracking-widest">{req.status}</p>
                          </div>
                        </div>
                        <div className="flex gap-2 w-full sm:w-auto">
                           <button className="flex-1 sm:flex-none px-4 py-2 bg-emerald-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg">Accept</button>
                           <button className="flex-1 sm:flex-none px-4 py-2 bg-zinc-200 text-zinc-500 rounded-xl text-[9px] font-black uppercase tracking-widest">Ignore</button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                  <div className="space-y-6">
                    <h5 className="text-[9px] font-black uppercase text-emerald-500 tracking-widest">Trust Inbound (Beacons)</h5>
                    <div className="space-y-3">
                      {user.verifiedStakes.length === 0 ? (
                        <p className="text-[10px] text-zinc-300 italic">No verified stakes active</p>
                      ) : (
                        user.verifiedStakes.map(s => (
                          <div key={s.id} className="p-5 bg-zinc-50 rounded-2xl border border-zinc-100 flex items-center justify-between">
                            <p className="text-xs font-bold text-black truncate pr-4">{s.label}</p>
                            <span className="text-[10px] font-black text-emerald-600">{(s.witnesses?.length || 0)} Witnesses</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                  <div className="space-y-6">
                    <h5 className="text-[9px] font-black uppercase text-blue-500 tracking-widest">Vouches Outbound (Guardians)</h5>
                    <div className="p-8 bg-zinc-50 rounded-[2rem] border border-dashed border-zinc-200 flex flex-col items-center justify-center text-center space-y-4 opacity-40">
                       <svg className="w-8 h-8 text-zinc-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                       <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">No active vouches found</p>
                    </div>
                  </div>
                </div>
              )}
           </section>
        </div>

        <div className="space-y-10">
           <section className="bg-zinc-950 text-white rounded-[2rem] lg:rounded-[3rem] p-10 lg:p-12 space-y-10 grain-overlay relative shadow-2xl">
              <div className="space-y-2">
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500">Active Intent</h4>
                <p className="text-3xl lg:text-4xl font-serif italic text-white tracking-tighter leading-snug">
                  "{user.calibrationHistory[user.calibrationHistory.length-1]?.intent || 'Uncalibrated'}"
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500">Current Frequency</p>
                <p className="text-2xl font-bold text-white uppercase tracking-widest">
                  {user.calibrationHistory[user.calibrationHistory.length-1]?.dominantEmotion || 'NULL'}
                </p>
              </div>
              <div className="pt-8 border-t border-white/10">
                 <button 
                  onClick={onOpenCalibration}
                  className="w-full py-5 bg-white text-black rounded-[1.5rem] text-[10px] font-black uppercase tracking-[0.4em] hover:scale-[1.05] transition-all shadow-xl"
                >
                  Run New Sync
                </button>
              </div>
           </section>

           <section className="bg-white border border-zinc-100 rounded-[2rem] lg:rounded-[3rem] p-8 lg:p-10 space-y-8 shadow-sm">
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300">Resonance History</h4>
              <div className="space-y-5">
                {[
                  { label: 'Sanctum Pod 1', access: '98%', status: 'Stable' },
                  { label: 'Mirror Audit', access: '72%', status: 'Deep' },
                  { label: 'Public Garden', access: '100%', status: 'Active' }
                ].map(p => (
                  <div key={p.label} className="flex items-center justify-between py-4 border-b border-zinc-50 last:border-none">
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-black">{p.label}</p>
                      <p className="text-[8px] font-black uppercase tracking-widest text-zinc-400">{p.status}</p>
                    </div>
                    <span className="text-xs font-mono font-bold text-zinc-600">{p.access}</span>
                  </div>
                ))}
              </div>
           </section>
        </div>
      </div>
    </div>
  );
};

export default PulseDashboard;
