
import React, { useState, useEffect } from 'react';
import { VulnerableUser, AlignmentRequest } from '../types';

interface Props {
  user: VulnerableUser;
  onSendRequest: (userId: string) => void;
  requests: AlignmentRequest[];
  onViewPeer: (handle: string) => void;
}

const ResonanceRadar: React.FC<Props> = ({ user, onSendRequest, requests, onViewPeer }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [matches, setMatches] = useState<any[]>([]);

  const handleScan = () => {
    setIsScanning(true);
    // Simulated spectral matching logic
    setTimeout(() => {
      const mockPeers = [
        { id: 'u-aris', name: 'Dr. Aris V.', handle: '@ArisEthics', affinity: 90 + Math.floor(Math.random() * 10), reason: `Resonance found in ${user.calibrationHistory[user.calibrationHistory.length-1]?.dominantEmotion || 'shared'} patterns.` },
        { id: 'u-elena', name: 'Elena K.', handle: '@Elena_Growth', affinity: 80 + Math.floor(Math.random() * 15), reason: 'Shared Relationship Forge history' },
        { id: 'u-marcus', name: 'Marcus L.', handle: '@MarcusLead', affinity: 75 + Math.floor(Math.random() * 20), reason: 'High-stakes strategy integrity match' }
      ];
      setMatches(mockPeers);
      setIsScanning(false);
    }, 2500);
  };

  useEffect(() => {
    if (matches.length === 0) handleScan();
  }, []);

  const isAlreadySent = (userId: string) => requests.some(r => r.toUserId === userId && r.status === 'pending');

  return (
    <div className="space-y-12 animate-slide-up pb-20 max-w-6xl mx-auto">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-[10px] font-black uppercase tracking-widest">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            AI Insight Engine
          </div>
          <h2 className="text-6xl font-serif font-bold tracking-tighter text-black leading-none">Resonance <span className="text-zinc-300">Radar</span></h2>
          <p className="text-zinc-400 text-sm font-bold uppercase tracking-[0.3em]">Discover peers through verified shared struggles.</p>
        </div>
        <button 
          onClick={handleScan}
          disabled={isScanning}
          className="px-8 py-4 bg-black text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
        >
          {isScanning ? 'Syncing Spectral Core...' : 'Refresh Spectral Scan'}
        </button>
      </header>

      {isScanning ? (
        <div className="h-[400px] flex flex-col items-center justify-center space-y-8 animate-pulse text-zinc-300">
           <div className="relative w-32 h-32">
              <div className="absolute inset-0 border-4 border-black/5 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-black border-t-transparent rounded-full animate-spin"></div>
           </div>
           <p className="text-[10px] font-black uppercase tracking-[0.5em]">Scanning Peer Integrity Ledger...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {matches.map((match) => (
            <div key={match.id} className="group p-8 rounded-[2.5rem] border border-zinc-100 bg-white hover:border-black transition-all duration-500 shadow-sm hover:shadow-2xl">
              <div className="flex justify-between items-start mb-10">
                <button 
                  onClick={() => onViewPeer(match.handle)}
                  className="w-16 h-16 rounded-[1.5rem] bg-zinc-50 flex items-center justify-center font-bold text-2xl text-zinc-300 group-hover:bg-black group-hover:text-white transition-all shadow-sm"
                >
                  {match.name.charAt(0)}
                </button>
                <div className="text-right">
                  <span className="text-3xl font-serif italic font-bold text-black">{match.affinity}%</span>
                  <p className="text-[9px] font-black uppercase tracking-widest text-zinc-300">Resonance</p>
                </div>
              </div>
              <div className="space-y-4">
                <button onClick={() => onViewPeer(match.handle)} className="text-left group/name">
                  <h3 className="text-xl font-bold tracking-tight text-black group-hover/name:underline">{match.name}</h3>
                  <p className="text-xs font-mono text-zinc-400">{match.handle}</p>
                </button>
                <div className="pt-6 border-t border-zinc-50">
                  <p className="text-[10px] font-black uppercase tracking-widest text-blue-500 mb-2">Mirror Logic</p>
                  <p className="text-sm font-medium text-zinc-600 leading-relaxed italic">"{match.reason}"</p>
                </div>
              </div>
              <button 
                onClick={() => onSendRequest(match.id)}
                disabled={isAlreadySent(match.id)}
                className={`w-full mt-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  isAlreadySent(match.id) 
                    ? 'bg-zinc-100 text-zinc-400 cursor-not-allowed' 
                    : 'bg-zinc-50 text-black hover:bg-black hover:text-white'
                }`}
              >
                {isAlreadySent(match.id) ? 'Request Pending' : 'Request Alignment'}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ResonanceRadar;
