
export enum IdentityStatus {
  UNVERIFIED = 'UNVERIFIED',
  PENDING = 'PENDING',
  VERIFIED = 'VERIFIED'
}

export type VisibilityTier = 'public' | 'shrouded' | 'locked';

export type FeedChannel = 'garden' | 'void' | 'forge' | 'mirror';

export interface TruthEquity {
  score: number;
  level: string; 
  percentile: number;
  recentGrowth: number;
}

export interface CalibrationData {
  alignment: number; 
  dominantEmotion: string;
  intent: string;
  timestamp: Date;
  aiInsight?: string;
}

export interface ForgeResult {
  id: string;
  dilemma: string;
  summary: string;
  riskScore: number; 
  integrityScore: number;
  precedents: { title: string; uri: string }[];
  actionSteps: string[];
  timestamp: Date;
}

export interface ProfileSectionConfig {
  id: string;
  type: string;
  label: string;
  tier: VisibilityTier;
  isVisible: boolean;
  order: number;
}

export interface VerifiedStake {
  id: string;
  label: string;
  description: string;
  verificationSource: string;
  witnesses: string[]; // User IDs who have witnessed this stake
}

export interface AlignmentRequest {
  id: string;
  fromUserId: string;
  fromUserName: string;
  toUserId: string;
  status: 'pending' | 'accepted' | 'declined';
  timestamp: Date;
}

export interface User {
  id: string;
  name: string;
  verifiedAttributes: string[];
}

export interface VulnerableUser extends User {
  legalHandle: string;
  displayName: string;
  bio: string;
  identityStatus: IdentityStatus;
  profileLayout: ProfileSectionConfig[];
  verifiedStakes: VerifiedStake[]; 
  blockedUserHandles: string[]; 
  truthEquity: TruthEquity;
  calibrationHistory: CalibrationData[];
  forgeHistory: ForgeResult[];
  lastSignificantDisclosure?: {
    date: Date;
    summary: string;
  };
  profileSections: {
    hobbies: string[];
    addictions: { title: string; status: 'past' | 'present' }[];
    regrets: string[];
    sexualPreferences: string[];
    genderIdentities: string[];
    favoriteMusic: string[];
    favoriteFood: string[];
    entrepreneurship: string;
    relationshipStatus: string;
    websiteUrl: string;
  };
  materialItems: MaterialItem[];
}

export interface MaterialItem {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  history: string;
  dateAdded: Date;
}

export interface Comment {
  id: string;
  authorName: string;
  authorHandle: string;
  content: string;
  timestamp: Date;
}

export interface FeedPost {
  id: string;
  authorHandle: string;
  authorName: string;
  content: string;
  type: 'text' | 'photo' | 'video';
  channel: FeedChannel;
  timestamp: Date;
  isModelCitizen?: boolean;
  comments?: Comment[];
  witnessCount?: number;
  resonanceCount?: number;
  isShrouded?: boolean;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  isFacilitator?: boolean;
}

export interface Pod {
  id: string;
  name: string;
  topic: string;
  members: { id: string; name: string }[];
  messages: Message[];
}

export interface VaultCase {
  id: string;
  title: string;
  category: string;
  struggle: string;
  outcome: string;
  tags: string[];
  sentiment: string;
}

export interface ModelTrait {
  id: string;
  category: string;
  trait: string;
  votes: number;
}
