
import { VulnerableUser, IdentityStatus, FeedPost, ModelTrait, VaultCase, Pod } from './types';

export const MOCK_ME: VulnerableUser = {
  id: 'me',
  name: 'Hunter',
  verifiedAttributes: ['Identity Verification Complete'],
  legalHandle: '@HunterCovert111',
  displayName: 'Hunter',
  bio: 'Building a medium for the parts of us we usually hide.',
  identityStatus: IdentityStatus.VERIFIED,
  blockedUserHandles: [],
  truthEquity: {
    score: 842,
    level: 'Absolute',
    percentile: 98,
    recentGrowth: 12
  },
  calibrationHistory: [
    { alignment: 75, dominantEmotion: 'Anxious', intent: 'Transparency', timestamp: new Date(Date.now() - 86400000) },
    { alignment: 92, dominantEmotion: 'Clear', intent: 'Directness', timestamp: new Date() }
  ],
  verifiedStakes: [
    { 
      id: 's1', 
      label: 'Career Stability', 
      description: 'Public disclosure of mental health struggles led to a forced sabbatical.', 
      verificationSource: 'Corporate HR Log',
      // Fixed: Added missing 'witnesses' property required by VerifiedStake interface
      witnesses: [] 
    }
  ],
  lastSignificantDisclosure: {
    date: new Date(Date.now() - 432000000), 
    summary: 'Admitted to the team that I lacked confidence in the Q4 strategy.'
  },
  profileLayout: [
    { id: 'bio', type: 'bio', label: 'Narrative', tier: 'public', isVisible: true, order: 0 },
    { id: 'stakes', type: 'stakes', label: 'Verified Stakes', tier: 'public', isVisible: true, order: 1 },
  ],
  // Added forgeHistory to satisfy VulnerableUser interface requirements
  forgeHistory: [],
  profileSections: {
    hobbies: ['Architecture', 'Cycling'],
    addictions: [{ title: 'Social Validation', status: 'past' }],
    regrets: ['Underestimating the cost of rapid growth.'],
    sexualPreferences: ['Confidential'],
    genderIdentities: ['Male'],
    favoriteMusic: ['Classical'],
    favoriteFood: ['None specified'],
    entrepreneurship: 'Focused on high-integrity social infrastructure.',
    relationshipStatus: 'Private',
    websiteUrl: 'https://vulnerable.com'
  },
  materialItems: []
};

export const MOCK_FEED: FeedPost[] = [
  {
    id: 'p1',
    authorHandle: '@SarahJenkins22',
    authorName: 'Sarah',
    content: 'Today I admitted to my partner that I still have a fear of failure that keeps me up at night. It was terrifying, but the relief is incredible.',
    type: 'text',
    channel: 'garden',
    timestamp: new Date(Date.now() - 3600000),
    comments: [
      { id: 'c1', authorName: 'Marcus', authorHandle: '@MarcusVibe', content: 'The relief is the reward for the risk.', timestamp: new Date() }
    ],
    witnessCount: 142,
    isShrouded: false
  },
  {
    id: 'p2',
    authorHandle: '@MarcusVibe',
    authorName: 'Marcus',
    content: 'The pressure to perform in my new role is immense. I often feel like an impostor, like I am playing a part in a play where everyone else knows their lines except me.',
    type: 'text',
    channel: 'forge',
    timestamp: new Date(Date.now() - 10800000),
    comments: [],
    witnessCount: 89,
    isShrouded: true
  }
];

export const MOCK_PODS: Pod[] = [
  {
    id: 'pod-1',
    name: 'The Inner Circle',
    topic: 'High-Stakes Leadership & Integrity',
    members: [
      { id: 'me', name: 'Hunter' },
      { id: 'u2', name: 'Sarah' },
      { id: 'u3', name: 'Marcus' }
    ],
    messages: [
      {
        id: 'm1',
        senderId: 'u2',
        senderName: 'Sarah',
        content: "I'm struggling with the trade-off between speed and transparency in our next release.",
        timestamp: new Date(Date.now() - 3600000)
      }
    ]
  }
];

export const CATEGORIES = ['Integrity', 'Resilience', 'Shadow Work', 'Relationship Tech', 'Corporate Ethics'];

export const MOCK_VAULT: VaultCase[] = [
  {
    id: 'V-001',
    title: 'The Sabbatical Protocol',
    category: 'Integrity',
    struggle: 'A founder facing burnout admitted to the board that they could no longer function effectively, risking a massive funding round.',
    outcome: 'The round was delayed, but the founder returned after 3 months with a restructured leadership team. 100% retention achieved.',
    tags: ['burnout', 'leadership', 'fundraising'],
    sentiment: 'Positive'
  }
];

export const MOCK_TRAITS: ModelTrait[] = [
  { id: 't1', category: 'Integrity', trait: 'Radical Candor', votes: 1240 }
];
