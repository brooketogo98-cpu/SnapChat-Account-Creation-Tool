
import * as React from 'react';
import { useState, useEffect } from 'react';
import { MOCK_ME, MOCK_FEED, MOCK_PODS, MOCK_VAULT } from './constants';
import { FeedChannel, VulnerableUser, CalibrationData, FeedPost, Pod, Message, VaultCase, IdentityStatus, ForgeResult, MaterialItem, AlignmentRequest } from './types';
import Layout from './components/Layout';
import Feed from './components/Feed';
import Profile from './components/Profile';
import LiveSanctuary from './components/LiveSanctuary';
import PodView from './components/PodView';
import Vault from './components/Vault';
import Gatekeeper from './components/Gatekeeper';
import VulnerabilityWizard from './components/VulnerabilityWizard';
import ResonanceRadar from './components/ResonanceRadar';
import ForgeAnalysis from './components/ForgeAnalysis';
import PulseDashboard from './components/PulseDashboard';
import CalibrationWizard from './components/CalibrationWizard';
import Auth from './components/Auth';
import MaterialArchive from './components/MaterialArchive';

const dateReviver = (key: string, value: any) => {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(value)) {
    return new Date(value);
  }
  return value;
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => localStorage.getItem('v_auth') === 'true');
  
  const [currentUser, setCurrentUser] = useState<VulnerableUser>(() => {
    const saved = localStorage.getItem('v_user');
    return saved ? JSON.parse(saved, dateReviver) : { ...MOCK_ME, forgeHistory: [], materialItems: [] };
  });

  const [allPosts, setAllPosts] = useState<FeedPost[]>(() => {
    const saved = localStorage.getItem('v_feed');
    return saved ? JSON.parse(saved, dateReviver) : MOCK_FEED;
  });

  const [peers, setPeers] = useState<Record<string, VulnerableUser>>(() => {
    const saved = localStorage.getItem('v_peers');
    return saved ? JSON.parse(saved, dateReviver) : {};
  });

  const [allPods, setAllPods] = useState<Pod[]>(() => {
    const saved = localStorage.getItem('v_pods');
    return saved ? JSON.parse(saved, dateReviver) : MOCK_PODS;
  });

  const [alignmentRequests, setAlignmentRequests] = useState<AlignmentRequest[]>(() => {
    const saved = localStorage.getItem('v_alignments');
    return saved ? JSON.parse(saved, dateReviver) : [];
  });

  const [allVaultCases, setAllVaultCases] = useState<VaultCase[]>(() => {
    const saved = localStorage.getItem('v_vault');
    return saved ? JSON.parse(saved, dateReviver) : MOCK_VAULT;
  });

  const [activeView, setActiveView] = useState('feed');
  const [activeChannel, setActiveChannel] = useState<FeedChannel>('garden');
  const [isSanctuaryOpen, setIsSanctuaryOpen] = useState(false);
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isCalibrationOpen, setIsCalibrationOpen] = useState(false);
  const [zenMode, setZenMode] = useState(false);
  const [selectedPeerHandle, setSelectedPeerHandle] = useState<string | null>(null);

  useEffect(() => { localStorage.setItem('v_user', JSON.stringify(currentUser)); }, [currentUser]);
  useEffect(() => { localStorage.setItem('v_feed', JSON.stringify(allPosts)); }, [allPosts]);
  useEffect(() => { localStorage.setItem('v_pods', JSON.stringify(allPods)); }, [allPods]);
  useEffect(() => { localStorage.setItem('v_vault', JSON.stringify(allVaultCases)); }, [allVaultCases]);
  useEffect(() => { localStorage.setItem('v_alignments', JSON.stringify(alignmentRequests)); }, [alignmentRequests]);
  useEffect(() => { localStorage.setItem('v_peers', JSON.stringify(peers)); }, [peers]);

  const handleLogin = (name: string, handle: string) => {
    const updatedUser = { ...currentUser, displayName: name, legalHandle: handle.startsWith('@') ? handle : `@${handle}` };
    setCurrentUser(updatedUser);
    setIsAuthenticated(true);
    localStorage.setItem('v_auth', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('v_auth');
    setActiveView('feed');
  };

  const handleWitnessStake = (userId: string, stakeId: string) => {
    if (userId === currentUser.id) return;

    setCurrentUser(prev => ({
      ...prev,
      truthEquity: { ...prev.truthEquity, score: prev.truthEquity.score + 5 }
    }));
    
    setPeers(prev => {
      const peer = prev[userId];
      if (!peer) return prev;
      return {
        ...prev,
        [userId]: {
          ...peer,
          verifiedStakes: peer.verifiedStakes.map(s => 
            s.id === stakeId ? { ...s, witnesses: [...new Set([...(s.witnesses || []), currentUser.id])] } : s
          )
        }
      };
    });
  };

  const handleViewPeer = (handle: string) => {
    const peerList = Object.values(peers) as VulnerableUser[];
    const existingPeer = peerList.find(p => p.legalHandle === handle);
    
    if (existingPeer) {
      setSelectedPeerHandle(handle);
      setActiveView('profile');
      return;
    }

    const peerPost = allPosts.find(p => p.authorHandle === handle);
    if (peerPost) {
      const peerId = `peer-${handle.replace('@', '')}-${Date.now()}`;
      const newPeer: VulnerableUser = {
        ...MOCK_ME,
        id: peerId,
        displayName: peerPost.authorName,
        legalHandle: peerPost.authorHandle,
        bio: "Analyzing the delta between public persona and internal reality.",
        truthEquity: { score: 450, level: 'Evolving', percentile: 62, recentGrowth: 5 },
        verifiedStakes: [
          { 
            id: `ps-${Date.now()}`, 
            label: 'Disclosure Integrity', 
            description: 'Publicly acknowledged systematic failure in previous organizational role.', 
            verificationSource: 'Council Audit', 
            witnesses: [] 
          }
        ],
        identityStatus: IdentityStatus.VERIFIED,
        profileLayout: [
          { id: 'bio', type: 'bio', label: 'Narrative', tier: 'public', isVisible: true, order: 0 },
          { id: 'stakes', type: 'stakes', label: 'Verified Stakes', tier: 'public', isVisible: true, order: 1 },
          { id: 'shards', type: 'shards', label: 'Narrative Shards', tier: 'shrouded', isVisible: true, order: 2 },
        ],
        profileSections: { ...MOCK_ME.profileSections, regrets: ["Hesitating when transparency was most critical."] }
      };
      
      setPeers(prev => ({ ...prev, [peerId]: newPeer }));
      setSelectedPeerHandle(handle);
      setActiveView('profile');
    }
  };

  const handleSendAlignmentRequest = (toUserId: string) => {
    const newRequest: AlignmentRequest = {
      id: `req-${Date.now()}`,
      fromUserId: currentUser.id,
      fromUserName: currentUser.displayName,
      toUserId,
      status: 'pending',
      timestamp: new Date()
    };
    setAlignmentRequests(prev => [newRequest, ...prev]);
  };

  const handleAddForgeResult = (result: ForgeResult) => {
    setCurrentUser(prev => ({
      ...prev,
      forgeHistory: [result, ...prev.forgeHistory],
      truthEquity: { ...prev.truthEquity, score: prev.truthEquity.score + 25 }
    }));
  };

  const handleRegisterMaterial = (item: MaterialItem) => {
    setCurrentUser(prev => ({
      ...prev,
      materialItems: [item, ...prev.materialItems],
      truthEquity: { ...prev.truthEquity, score: prev.truthEquity.score + 15 }
    }));
  };

  const handleSendMessage = (podId: string, content: string, isFacilitator: boolean = false) => {
    setAllPods(prev => prev.map(pod => {
      if (pod.id === podId) {
        const newMessage: Message = {
          id: `msg-${Date.now()}`,
          senderId: isFacilitator ? 'sanctum-ai' : currentUser.id,
          senderName: isFacilitator ? 'Facilitator' : currentUser.displayName,
          content,
          timestamp: new Date(),
          isFacilitator
        };
        return { ...pod, messages: [...pod.messages, newMessage] };
      }
      return pod;
    }));
  };

  const handleVerifyAttribute = (attribute: string) => {
    setCurrentUser(prev => ({
      ...prev,
      verifiedAttributes: [...new Set([...prev.verifiedAttributes, attribute])],
      identityStatus: prev.verifiedAttributes.length >= 2 ? IdentityStatus.VERIFIED : IdentityStatus.PENDING,
      truthEquity: { ...prev.truthEquity, score: prev.truthEquity.score + 50 }
    }));
  };

  const handleAddPost = (content: string, channel: FeedChannel) => {
    const newPost: FeedPost = {
      id: `post-${Date.now()}`,
      authorHandle: currentUser.legalHandle,
      authorName: currentUser.displayName,
      content,
      type: 'text',
      channel,
      timestamp: new Date(),
      witnessCount: 0,
      isShrouded: false,
      comments: []
    };
    setAllPosts(prev => [newPost, ...prev]);
    setCurrentUser(prev => ({
      ...prev,
      truthEquity: { ...prev.truthEquity, score: prev.truthEquity.score + 10, recentGrowth: prev.truthEquity.recentGrowth + 1 },
      lastSignificantDisclosure: { date: new Date(), summary: content.slice(0, 60) + '...' }
    }));
  };

  // Fix: Implemented handleCalibrationComplete to update user calibration history and truth equity
  const handleCalibrationComplete = (data: CalibrationData) => {
    setCurrentUser(prev => ({
      ...prev,
      calibrationHistory: [...prev.calibrationHistory, data],
      truthEquity: {
        ...prev.truthEquity,
        score: prev.truthEquity.score + 20,
        recentGrowth: prev.truthEquity.recentGrowth + 2
      }
    }));
    setIsCalibrationOpen(false);
  };

  const activePeer = selectedPeerHandle ? (Object.values(peers) as VulnerableUser[]).find(p => p.legalHandle === selectedPeerHandle) : null;

  const renderContent = () => {
    switch (activeView) {
      case 'feed': return <Feed posts={allPosts} channel={activeChannel} blockedUserHandles={currentUser.blockedUserHandles} onBlockUser={(h) => {}} onAddPost={handleAddPost} onEnterSanctuary={() => setIsSanctuaryOpen(true)} onViewPeer={handleViewPeer} />;
      case 'forge': return <ForgeAnalysis onSaveResult={handleAddForgeResult} history={currentUser.forgeHistory} />;
      case 'pulse': return <PulseDashboard user={currentUser} onOpenCalibration={() => setIsCalibrationOpen(true)} alignmentRequests={alignmentRequests} />;
      case 'sanctum': return <PodView user={currentUser} pod={allPods[0]} onSendMessage={handleSendMessage} />;
      case 'vault': return <Vault cases={allVaultCases} userForgeHistory={currentUser.forgeHistory} />;
      case 'gatekeeper': return <Gatekeeper user={currentUser} onVerify={handleVerifyAttribute} />;
      case 'radar': return <ResonanceRadar user={currentUser} onSendRequest={handleSendAlignmentRequest} requests={alignmentRequests} onViewPeer={handleViewPeer} />;
      case 'material': return <MaterialArchive items={currentUser.materialItems} onRegister={handleRegisterMaterial} />;
      case 'profile': return <Profile user={activePeer || currentUser} posts={allPosts.filter(p => p.authorHandle === (activePeer?.legalHandle || currentUser.legalHandle))} onWitnessStake={handleWitnessStake} isMe={!activePeer} onBack={() => setSelectedPeerHandle(null)} />;
      default: return <Feed posts={allPosts} channel="garden" blockedUserHandles={currentUser.blockedUserHandles} onBlockUser={(h) => {}} onAddPost={handleAddPost} onViewPeer={handleViewPeer} />;
    }
  };

  return (
    <>
      <Layout 
        user={currentUser} 
        activeView={activeView} 
        activeChannel={activeChannel} 
        setActiveView={(v) => { setActiveView(v); setSelectedPeerHandle(null); }} 
        setActiveChannel={setActiveChannel} 
        onOpenCalibration={() => setIsCalibrationOpen(true)} 
        onLogout={handleLogout} 
        zenMode={zenMode}
      >
        <div className={`transition-all duration-1000 ${zenMode ? 'max-w-3xl mx-auto py-20 lg:py-40' : ''}`}>
           {renderContent()}
        </div>
      </Layout>
      <LiveSanctuary isOpen={isSanctuaryOpen} onClose={() => setIsSanctuaryOpen(false)} />
      {isWizardOpen && <VulnerabilityWizard onCancel={() => setIsWizardOpen(false)} onComplete={(data) => { handleAddPost(data.struggle, 'garden'); setIsWizardOpen(false); setActiveView('feed'); }} />}
      {isCalibrationOpen && <CalibrationWizard onCancel={() => setIsCalibrationOpen(false)} onComplete={handleCalibrationComplete} />}
      
      <div className={`fixed bottom-8 right-8 lg:bottom-12 lg:right-12 flex flex-col items-center gap-4 z-[100] transition-transform duration-500 ${zenMode ? 'translate-y-4 opacity-50 hover:translate-y-0 hover:opacity-100' : ''}`}>
        <button 
          onClick={() => setZenMode(!zenMode)} 
          title={zenMode ? "Exit Zen Mode" : "Enter Zen Mode"} 
          className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${zenMode ? 'bg-black text-white' : 'bg-white text-zinc-400 border border-zinc-100 shadow-xl'}`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
        </button>
        <button 
          onClick={() => setIsWizardOpen(true)} 
          title="Add Truth Disclosure" 
          className="w-16 h-16 bg-black text-white rounded-[2rem] shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all group"
        >
          <svg className="w-7 h-7 transition-transform group-hover:rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4" /></svg>
        </button>
      </div>
    </>
  );
};

export default App;
