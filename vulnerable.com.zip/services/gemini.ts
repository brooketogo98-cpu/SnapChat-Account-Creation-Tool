
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Standard content moderation with professional auditing tone.
 */
export const moderateContent = async (content: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `AUDIT PROTOCOL: Analyze the following user disclosure for catastrophic risk (self-harm, violent threats, illegal activity).
    
    Status Categories: 
    'HIGH_RISK' (Requires immediate intervention), 
    'MEDIUM_RISK' (Passive aggressive or mild toxicity), 
    'LOW_RISK' (Healthy radical honesty). 
    
    Return JSON.
    Text: "${content}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING },
          reason: { type: Type.STRING }
        },
        required: ['status', 'reason']
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}');
  } catch (e) {
    return { status: 'LOW_RISK', reason: 'Parse Error' };
  }
};

/**
 * Calibrates the user's emotional state to update their Truth Equity.
 */
export const runCalibrationAI = async (feelings: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `CALIBRATION PROTOCOL: Analyze the current internal state: "${feelings}". 
    Calculate:
    1. Alignment (0-100): How congruent is the user today?
    2. Dominant Emotion: One word.
    3. Intent: A daily mission for radical honesty.
    4. Insight: A professional psychological observation. 
    Return JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          alignment: { type: Type.NUMBER },
          emotion: { type: Type.STRING },
          intent: { type: Type.STRING },
          insight: { type: Type.STRING }
        },
        required: ['alignment', 'emotion', 'intent', 'insight']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

/**
 * Analyzes the collective sentiment of a group conversation.
 */
export const analyzeGroupFrequency = async (messages: string[]) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `SPECTRAL SWEEP: Analyze the following group dialogue for collective frequency.
    Dialogue: ${JSON.stringify(messages)}
    
    Calculate:
    1. Frequency (One of: Unified, Discordant, Melancholic, Resilient, Anxious, Evolving)
    2. Resonance Score (0-100)
    3. Heatmap Value (0-1: 0 is cold/disengaged, 1 is hot/intense)
    
    Return JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          frequency: { type: Type.STRING },
          resonanceScore: { type: Type.NUMBER },
          heatmapValue: { type: Type.NUMBER }
        },
        required: ['frequency', 'resonanceScore', 'heatmapValue']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

/**
 * Strategic analysis using Google Search grounding.
 */
export const analyzeForgeStakes = async (dilemma: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `STRATEGIC AUDIT: We are analyzing an integrity dilemma: "${dilemma}". 
    Use Google Search to find real-world business case studies, ethical precedents, or legal outcomes for similar situations. 
    Focus on high-stakes corporate or personal outcomes where integrity led to long-term gain or systemic failure.
    
    Return JSON:
    'summary': Deep ethical analysis (approx 100 words).
    'riskScore': 0-100.
    'integrityScore': 0-100.
    'actionSteps': 3-5 tactical requirements for resolving with integrity.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json"
    }
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
    title: chunk.web?.title || 'Case Study Reference',
    uri: chunk.web?.uri || '#'
  })) || [];

  try {
    const data = JSON.parse(response.text || '{}');
    return { ...data, precedents: sources };
  } catch (e) {
    return { 
      summary: "Analysis of the dilemma suggests a standard integrity mismatch. Historical precedents indicate that radical transparency often preserves valuation over the long term.", 
      riskScore: 65, 
      integrityScore: 80, 
      actionSteps: ["Immediate disclosure to key stakeholders", "Audit internal communication logs", "Draft a resolution charter"], 
      precedents: sources 
    };
  }
};

/**
 * Mirror reflection: Analyzes past disclosures to provide a 'Shadow Report'.
 */
export const getMirrorReflection = async (postHistory: string[]) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `MIRROR PROTOCOL: The user has disclosed the following truths recently: ${JSON.stringify(postHistory)}. 
    Analyze the subtext and patterns of avoidance. Identify:
    1. Shadow Pattern: What are they specifically not saying?
    2. Growth Vector: What is the most courageous next step for them?
    Return JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          shadowPattern: { type: Type.STRING },
          growthVector: { type: Type.STRING }
        },
        required: ['shadowPattern', 'growthVector']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const getFacilitatorPrompt = async (history: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `SANCTUM FACILITATOR: We are in a high-integrity peer council. 
    Analyze the recent dialogue and identify one subtle contradiction or a 'safe' area the group is hiding behind.
    Provide a deep, challenging question to shatter the surface level. 
    History: ${history}`,
  });
  return response.text;
};
